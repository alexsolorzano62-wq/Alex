--
-- PostgreSQL database dump
--

\restrict auxbtU2fde59WjHauqvUAzWPwQ8AN9sftP3hMa9zIMZb1NbzFbrZICd5NG3AdkD

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: cobros_inmutables(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cobros_inmutables() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if old.anulado_at is not null
     and new.anulado_at is not distinct from old.anulado_at then
    raise exception 'El recibo % está anulado: no se puede modificar.', old.numero;
  end if;

  if (new.numero, new.contrato_id, new.periodo, new.fecha_pago, new.total, new.moneda)
     is distinct from
     (old.numero, old.contrato_id, old.periodo, old.fecha_pago, old.total, old.moneda)
  then
    raise exception
      'Un recibo emitido no se edita. Anulá el recibo % y emití uno nuevo.',
      old.numero;
  end if;

  return new;
end;
$$;


--
-- Name: detalle_liquidacion_emitida(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.detalle_liquidacion_emitida() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
  emitida timestamptz;
  liq_id uuid;
begin
  liq_id := coalesce(new.liquidacion_id, old.liquidacion_id);
  select l.emitida_at into emitida
    from public.liquidaciones l where l.id = liq_id;

  if emitida is not null then
    raise exception 'La liquidación ya fue emitida: su detalle no se modifica.';
  end if;

  return coalesce(new, old);
end;
$$;


--
-- Name: es_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.es_admin() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select coalesce(
    (select rol = 'admin' from public.perfiles where id = auth.uid()),
    false
  );
$$;


--
-- Name: es_miembro(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.es_miembro() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select exists (select 1 from public.perfiles where id = auth.uid());
$$;


--
-- Name: liquidaciones_inmutables(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.liquidaciones_inmutables() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if old.emitida_at is null then
    return new;                          -- todavía es borrador: se edita libre
  end if;

  if (new.propietario_id, new.periodo, new.moneda,
      new.total_cobrado, new.total_honorarios, new.total_gastos,
      new.total_ajustes, new.neto_a_pagar)
     is distinct from
     (old.propietario_id, old.periodo, old.moneda,
      old.total_cobrado, old.total_honorarios, old.total_gastos,
      old.total_ajustes, old.neto_a_pagar)
  then
    raise exception
      'La liquidación % ya fue emitida: sus números no se modifican. Anulala y emití una nueva.',
      old.numero;
  end if;

  return new;
end;
$$;


--
-- Name: prohibir_borrado(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prohibir_borrado() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  raise exception
    'Esta tabla no admite borrado: anulá el registro para conservar el historial.';
end;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ajustes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ajustes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    contrato_id uuid NOT NULL,
    fecha_aplicacion date NOT NULL,
    periodo_desde date NOT NULL,
    periodo_hasta date NOT NULL,
    indice text NOT NULL,
    valor_indice_base numeric(20,8),
    valor_indice_final numeric(20,8),
    coeficiente numeric(12,6) NOT NULL,
    monto_anterior numeric(14,2) NOT NULL,
    monto_nuevo numeric(14,2) NOT NULL,
    notificado_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ajustes_coeficiente_check CHECK ((coeficiente > (0)::numeric))
);


--
-- Name: avisos_enviados; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.avisos_enviados (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tipo text NOT NULL,
    contrato_id uuid,
    liquidacion_id uuid,
    periodo date,
    destino text,
    enviado_at timestamp with time zone DEFAULT now() NOT NULL,
    enviado_por uuid,
    CONSTRAINT avisos_cuelgan_de_algo CHECK (((contrato_id IS NOT NULL) OR (liquidacion_id IS NOT NULL))),
    CONSTRAINT avisos_enviados_tipo_check CHECK ((tipo = ANY (ARRAY['vencimiento'::text, 'aumento'::text, 'liquidacion'::text, 'recibo'::text])))
);


--
-- Name: cobro_conceptos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cobro_conceptos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    cobro_id uuid NOT NULL,
    tipo text NOT NULL,
    descripcion text,
    monto numeric(14,2) NOT NULL,
    orden integer DEFAULT 0 NOT NULL,
    CONSTRAINT cobro_conceptos_tipo_check CHECK ((tipo = ANY (ARRAY['alquiler'::text, 'expensas'::text, 'abl'::text, 'luz'::text, 'gas'::text, 'agua'::text, 'punitorios'::text, 'reparacion'::text, 'ajuste_manual'::text, 'otro'::text])))
);


--
-- Name: recibo_numero_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recibo_numero_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cobros; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cobros (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    numero bigint DEFAULT nextval('public.recibo_numero_seq'::regclass) NOT NULL,
    contrato_id uuid NOT NULL,
    periodo date NOT NULL,
    fecha_pago date NOT NULL,
    vencimiento date NOT NULL,
    moneda text DEFAULT 'ARS'::text NOT NULL,
    total numeric(14,2) NOT NULL,
    medio_pago text DEFAULT 'transferencia'::text NOT NULL,
    comprobante_url text,
    notas text,
    emisiones integer DEFAULT 1 NOT NULL,
    anulado_at timestamp with time zone,
    anulado_motivo text,
    anulado_por uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT cobros_anulacion_con_motivo CHECK (((anulado_at IS NULL) OR (anulado_motivo IS NOT NULL))),
    CONSTRAINT cobros_emisiones_check CHECK ((emisiones >= 1)),
    CONSTRAINT cobros_medio_pago_check CHECK ((medio_pago = ANY (ARRAY['transferencia'::text, 'efectivo'::text, 'cheque'::text, 'deposito'::text, 'otro'::text]))),
    CONSTRAINT cobros_moneda_check CHECK ((moneda = ANY (ARRAY['ARS'::text, 'USD'::text]))),
    CONSTRAINT cobros_periodo_dia_1 CHECK ((EXTRACT(day FROM periodo) = (1)::numeric)),
    CONSTRAINT cobros_total_check CHECK ((total >= (0)::numeric))
);


--
-- Name: contratos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contratos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    propiedad_id uuid NOT NULL,
    inquilino_id uuid NOT NULL,
    garantes text,
    fecha_inicio date NOT NULL,
    fecha_fin date NOT NULL,
    destino text DEFAULT 'vivienda'::text NOT NULL,
    moneda text DEFAULT 'ARS'::text NOT NULL,
    monto_inicial numeric(14,2) NOT NULL,
    monto_actual numeric(14,2) NOT NULL,
    deposito_monto numeric(14,2),
    deposito_estado text DEFAULT 'retenido'::text NOT NULL,
    dia_vencimiento integer DEFAULT 10 NOT NULL,
    honorarios_porcentaje numeric(5,2) DEFAULT 8 NOT NULL,
    indice text DEFAULT 'ICL'::text NOT NULL,
    ajuste_frecuencia_meses integer DEFAULT 3 NOT NULL,
    ajuste_porcentaje_fijo numeric(6,3),
    fecha_ultimo_ajuste date,
    fecha_proximo_ajuste date,
    punitorio_tipo text DEFAULT 'porcentaje_diario'::text NOT NULL,
    punitorio_valor numeric(10,4) DEFAULT 0 NOT NULL,
    punitorio_dias_gracia integer DEFAULT 0 NOT NULL,
    estado text DEFAULT 'activo'::text NOT NULL,
    observaciones text,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT contratos_ajuste_fijo CHECK (((indice <> 'FIJO'::text) OR (ajuste_porcentaje_fijo IS NOT NULL))),
    CONSTRAINT contratos_ajuste_frecuencia_meses_check CHECK (((ajuste_frecuencia_meses >= 1) AND (ajuste_frecuencia_meses <= 36))),
    CONSTRAINT contratos_deposito_estado_check CHECK ((deposito_estado = ANY (ARRAY['retenido'::text, 'devuelto'::text, 'aplicado'::text, 'sin_deposito'::text]))),
    CONSTRAINT contratos_destino_check CHECK ((destino = ANY (ARRAY['vivienda'::text, 'comercial'::text, 'mixto'::text, 'otro'::text]))),
    CONSTRAINT contratos_dia_vencimiento_check CHECK (((dia_vencimiento >= 1) AND (dia_vencimiento <= 28))),
    CONSTRAINT contratos_estado_check CHECK ((estado = ANY (ARRAY['activo'::text, 'finalizado'::text, 'rescindido'::text]))),
    CONSTRAINT contratos_fechas CHECK ((fecha_fin > fecha_inicio)),
    CONSTRAINT contratos_honorarios_porcentaje_check CHECK (((honorarios_porcentaje >= (0)::numeric) AND (honorarios_porcentaje <= (100)::numeric))),
    CONSTRAINT contratos_indice_check CHECK ((indice = ANY (ARRAY['ICL'::text, 'IPC'::text, 'UVA'::text, 'CASA_PROPIA'::text, 'FIJO'::text, 'SIN_AJUSTE'::text]))),
    CONSTRAINT contratos_moneda_check CHECK ((moneda = ANY (ARRAY['ARS'::text, 'USD'::text]))),
    CONSTRAINT contratos_monto_actual_check CHECK ((monto_actual > (0)::numeric)),
    CONSTRAINT contratos_monto_inicial_check CHECK ((monto_inicial > (0)::numeric)),
    CONSTRAINT contratos_punitorio_dias_gracia_check CHECK ((punitorio_dias_gracia >= 0)),
    CONSTRAINT contratos_punitorio_tipo_check CHECK ((punitorio_tipo = ANY (ARRAY['porcentaje_diario'::text, 'monto_fijo_diario'::text, 'ninguno'::text]))),
    CONSTRAINT contratos_punitorio_valor_check CHECK ((punitorio_valor >= (0)::numeric))
);


--
-- Name: gastos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gastos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    propiedad_id uuid NOT NULL,
    contrato_id uuid,
    fecha date NOT NULL,
    tipo text DEFAULT 'otro'::text NOT NULL,
    descripcion text NOT NULL,
    monto numeric(14,2) NOT NULL,
    moneda text DEFAULT 'ARS'::text NOT NULL,
    a_cargo_de text DEFAULT 'propietario'::text NOT NULL,
    comprobante_url text,
    notas text,
    cobro_id uuid,
    liquidacion_id uuid,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT gastos_a_cargo_de_check CHECK ((a_cargo_de = ANY (ARRAY['propietario'::text, 'inquilino'::text]))),
    CONSTRAINT gastos_moneda_check CHECK ((moneda = ANY (ARRAY['ARS'::text, 'USD'::text]))),
    CONSTRAINT gastos_monto_check CHECK ((monto > (0)::numeric)),
    CONSTRAINT gastos_tipo_check CHECK ((tipo = ANY (ARRAY['expensas'::text, 'abl'::text, 'luz'::text, 'gas'::text, 'agua'::text, 'reparacion'::text, 'seguro'::text, 'honorarios_profesionales'::text, 'impuesto'::text, 'otro'::text])))
);


--
-- Name: indices_valores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indices_valores (
    indice text NOT NULL,
    fecha date NOT NULL,
    valor numeric(20,8) NOT NULL,
    actualizado_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT indices_valores_indice_check CHECK ((indice = ANY (ARRAY['ICL'::text, 'IPC'::text, 'UVA'::text, 'CASA_PROPIA'::text]))),
    CONSTRAINT indices_valores_valor_check CHECK ((valor > (0)::numeric))
);


--
-- Name: inquilinos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inquilinos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    nombre text NOT NULL,
    documento text,
    telefono text,
    email text,
    notas text,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: liquidacion_detalle; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.liquidacion_detalle (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    liquidacion_id uuid NOT NULL,
    contrato_id uuid,
    tipo text NOT NULL,
    cobro_id uuid,
    gasto_id uuid,
    descripcion text NOT NULL,
    monto_bruto numeric(14,2) NOT NULL,
    honorarios_porcentaje numeric(5,2),
    honorarios_monto numeric(14,2) DEFAULT 0 NOT NULL,
    neto numeric(14,2) NOT NULL,
    orden integer DEFAULT 0 NOT NULL,
    CONSTRAINT liquidacion_detalle_tipo_check CHECK ((tipo = ANY (ARRAY['cobro'::text, 'gasto'::text, 'ajuste'::text])))
);


--
-- Name: liquidacion_numero_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.liquidacion_numero_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: liquidaciones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.liquidaciones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    numero bigint DEFAULT nextval('public.liquidacion_numero_seq'::regclass) NOT NULL,
    propietario_id uuid NOT NULL,
    periodo date NOT NULL,
    moneda text DEFAULT 'ARS'::text NOT NULL,
    total_cobrado numeric(14,2) DEFAULT 0 NOT NULL,
    total_honorarios numeric(14,2) DEFAULT 0 NOT NULL,
    total_gastos numeric(14,2) DEFAULT 0 NOT NULL,
    total_ajustes numeric(14,2) DEFAULT 0 NOT NULL,
    neto_a_pagar numeric(14,2) DEFAULT 0 NOT NULL,
    estado text DEFAULT 'borrador'::text NOT NULL,
    metodo_pago text,
    fecha_pago date,
    comprobante_url text,
    conformidad text,
    recibido_por text,
    notas text,
    emitida_at timestamp with time zone,
    emitida_por uuid,
    anulado_at timestamp with time zone,
    anulado_motivo text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT liquidaciones_estado_check CHECK ((estado = ANY (ARRAY['borrador'::text, 'emitida'::text, 'pagada'::text, 'anulada'::text]))),
    CONSTRAINT liquidaciones_metodo_pago_check CHECK ((metodo_pago = ANY (ARRAY['transferencia'::text, 'efectivo'::text]))),
    CONSTRAINT liquidaciones_moneda_check CHECK ((moneda = ANY (ARRAY['ARS'::text, 'USD'::text]))),
    CONSTRAINT liquidaciones_pagada_completa CHECK (((estado <> 'pagada'::text) OR ((metodo_pago IS NOT NULL) AND (fecha_pago IS NOT NULL)))),
    CONSTRAINT liquidaciones_periodo_dia_1 CHECK ((EXTRACT(day FROM periodo) = (1)::numeric))
);


--
-- Name: perfiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.perfiles (
    id uuid NOT NULL,
    nombre text NOT NULL,
    email text NOT NULL,
    rol text DEFAULT 'operador'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT perfiles_rol_check CHECK ((rol = ANY (ARRAY['operador'::text, 'admin'::text])))
);


--
-- Name: propiedades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.propiedades (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    propietario_id uuid NOT NULL,
    titulares_adicionales text,
    direccion text NOT NULL,
    piso_depto text,
    localidad text,
    provincia text DEFAULT 'Buenos Aires'::text,
    tipo text DEFAULT 'departamento'::text NOT NULL,
    ambientes integer,
    superficie_m2 numeric(10,2),
    partida_inmobiliaria text,
    cuenta_luz text,
    cuenta_gas text,
    cuenta_agua text,
    expensas_unidad text,
    estado text DEFAULT 'alquilado'::text NOT NULL,
    notas text,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    edificio text,
    CONSTRAINT propiedades_estado_check CHECK ((estado = ANY (ARRAY['alquilado'::text, 'disponible'::text, 'en_refaccion'::text, 'retirado'::text]))),
    CONSTRAINT propiedades_tipo_check CHECK ((tipo = ANY (ARRAY['departamento'::text, 'casa'::text, 'ph'::text, 'monoambiente'::text, 'duplex'::text, 'local'::text, 'oficina'::text, 'galpon'::text, 'cochera'::text, 'terreno'::text, 'otro'::text])))
);


--
-- Name: COLUMN propiedades.edificio; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.propiedades.edificio IS 'Nombre del edificio. Si está vacío, la unidad se agrupa por su dirección.';


--
-- Name: propietarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.propietarios (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    nombre text NOT NULL,
    documento text,
    telefono text,
    email text,
    forma_cobro text DEFAULT 'transferencia'::text NOT NULL,
    cbu text,
    alias_cbu text,
    titular_cuenta text,
    notas text,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT propietarios_forma_cobro_check CHECK ((forma_cobro = ANY (ARRAY['transferencia'::text, 'efectivo'::text])))
);


--
-- Data for Name: ajustes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ajustes (id, contrato_id, fecha_aplicacion, periodo_desde, periodo_hasta, indice, valor_indice_base, valor_indice_final, coeficiente, monto_anterior, monto_nuevo, notificado_at, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: avisos_enviados; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.avisos_enviados (id, tipo, contrato_id, liquidacion_id, periodo, destino, enviado_at, enviado_por) FROM stdin;
\.


--
-- Data for Name: cobro_conceptos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cobro_conceptos (id, cobro_id, tipo, descripcion, monto, orden) FROM stdin;
\.


--
-- Data for Name: cobros; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cobros (id, numero, contrato_id, periodo, fecha_pago, vencimiento, moneda, total, medio_pago, comprobante_url, notas, emisiones, anulado_at, anulado_motivo, anulado_por, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: contratos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contratos (id, propiedad_id, inquilino_id, garantes, fecha_inicio, fecha_fin, destino, moneda, monto_inicial, monto_actual, deposito_monto, deposito_estado, dia_vencimiento, honorarios_porcentaje, indice, ajuste_frecuencia_meses, ajuste_porcentaje_fijo, fecha_ultimo_ajuste, fecha_proximo_ajuste, punitorio_tipo, punitorio_valor, punitorio_dias_gracia, estado, observaciones, deleted_at, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: gastos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gastos (id, propiedad_id, contrato_id, fecha, tipo, descripcion, monto, moneda, a_cargo_de, comprobante_url, notas, cobro_id, liquidacion_id, deleted_at, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: indices_valores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indices_valores (indice, fecha, valor, actualizado_at) FROM stdin;
IPC	2020-07-01	328.20140000	2026-08-31 22:02:54.272143+00
IPC	2020-08-01	337.06320000	2026-08-31 22:02:54.272143+00
IPC	2020-09-01	346.62070000	2026-08-31 22:02:54.272143+00
IPC	2020-10-01	359.65700000	2026-08-31 22:02:54.272143+00
IPC	2020-11-01	371.02110000	2026-08-31 22:02:54.272143+00
IPC	2020-12-01	385.88260000	2026-08-31 22:02:54.272143+00
IPC	2021-01-01	401.50710000	2026-08-31 22:02:54.272143+00
IPC	2021-02-01	415.85950000	2026-08-31 22:02:54.272143+00
IPC	2021-03-01	435.86570000	2026-08-31 22:02:54.272143+00
IPC	2021-04-01	453.65030000	2026-08-31 22:02:54.272143+00
IPC	2021-05-01	468.72500000	2026-08-31 22:02:54.272143+00
IPC	2021-06-01	483.60490000	2026-08-31 22:02:54.272143+00
IPC	2021-07-01	498.09870000	2026-08-31 22:02:54.272143+00
IPC	2021-08-01	510.39420000	2026-08-31 22:02:54.272143+00
IPC	2021-09-01	528.49680000	2026-08-31 22:02:54.272143+00
IPC	2021-10-01	547.08020000	2026-08-31 22:02:54.272143+00
IPC	2021-11-01	560.91840000	2026-08-31 22:02:54.272143+00
IPC	2021-12-01	582.45750000	2026-08-31 22:02:54.272143+00
IPC	2022-01-01	605.03170000	2026-08-31 22:02:54.272143+00
IPC	2022-02-01	633.43410000	2026-08-31 22:02:54.272143+00
IPC	2022-03-01	676.05660000	2026-08-31 22:02:54.272143+00
IPC	2022-04-01	716.93990000	2026-08-31 22:02:54.272143+00
IPC	2022-05-01	753.14700000	2026-08-31 22:02:54.272143+00
IPC	2022-06-01	793.02780000	2026-08-31 22:02:54.272143+00
IPC	2022-07-01	851.76100000	2026-08-31 22:02:54.272143+00
IPC	2022-08-01	911.13160000	2026-08-31 22:02:54.272143+00
IPC	2022-09-01	967.30760000	2026-08-31 22:02:54.272143+00
IPC	2022-10-01	1028.70600000	2026-08-31 22:02:54.272143+00
IPC	2022-11-01	1079.27870000	2026-08-31 22:02:54.272143+00
IPC	2022-12-01	1134.58750000	2026-08-31 22:02:54.272143+00
IPC	2023-01-01	1202.97900000	2026-08-31 22:02:54.272143+00
IPC	2023-02-01	1282.70910000	2026-08-31 22:02:54.272143+00
IPC	2023-03-01	1381.16010000	2026-08-31 22:02:54.272143+00
IPC	2023-04-01	1497.21470000	2026-08-31 22:02:54.272143+00
IPC	2023-05-01	1613.58950000	2026-08-31 22:02:54.272143+00
IPC	2023-06-01	1709.61150000	2026-08-31 22:02:54.272143+00
IPC	2023-07-01	1818.08380000	2026-08-31 22:02:54.272143+00
IPC	2023-08-01	2044.28320000	2026-08-31 22:02:54.272143+00
IPC	2023-09-01	2304.92420000	2026-08-31 22:02:54.272143+00
IPC	2023-10-01	2496.27300000	2026-08-31 22:02:54.272143+00
IPC	2023-11-01	2816.06280000	2026-08-31 22:02:54.272143+00
IPC	2023-12-01	3533.19220000	2026-08-31 22:02:54.272143+00
IPC	2024-01-01	4261.53240000	2026-08-31 22:02:54.272143+00
IPC	2024-02-01	4825.78810000	2026-08-31 22:02:54.272143+00
IPC	2024-03-01	5357.09290000	2026-08-31 22:02:54.272143+00
IPC	2024-04-01	5830.22710000	2026-08-31 22:02:54.272143+00
IPC	2024-05-01	6073.70000000	2026-08-31 22:02:54.272143+00
IPC	2024-06-01	6351.71450000	2026-08-31 22:02:54.272143+00
IPC	2024-07-01	6607.74790000	2026-08-31 22:02:54.272143+00
IPC	2024-08-01	6883.44120000	2026-08-31 22:02:54.272143+00
IPC	2024-09-01	7122.24210000	2026-08-31 22:02:54.272143+00
IPC	2024-10-01	7313.95420000	2026-08-31 22:02:54.272143+00
IPC	2024-11-01	7491.43140000	2026-08-31 22:02:54.272143+00
IPC	2024-12-01	7694.00750000	2026-08-31 22:02:54.272143+00
IPC	2025-01-01	7864.12570000	2026-08-31 22:02:54.272143+00
IPC	2025-02-01	8052.99270000	2026-08-31 22:02:54.272143+00
IPC	2025-03-01	8353.31580000	2026-08-31 22:02:54.272143+00
IPC	2025-04-01	8585.60780000	2026-08-31 22:02:54.272143+00
IPC	2025-05-01	8714.48710000	2026-08-31 22:02:54.272143+00
IPC	2025-06-01	8855.56810000	2026-08-31 22:02:54.272143+00
IPC	2025-07-01	9023.97300000	2026-08-31 22:02:54.272143+00
IPC	2025-08-01	9193.24410000	2026-08-31 22:02:54.272143+00
IPC	2025-09-01	9384.09220000	2026-08-31 22:02:54.272143+00
IPC	2025-10-01	9603.86230000	2026-08-31 22:02:54.272143+00
IPC	2025-11-01	9841.35810000	2026-08-31 22:02:54.272143+00
IPC	2025-12-01	10121.37150000	2026-08-31 22:02:54.272143+00
IPC	2026-01-01	10413.03090000	2026-08-31 22:02:54.272143+00
IPC	2026-02-01	10714.62550000	2026-08-31 22:02:54.272143+00
IPC	2026-03-01	11077.06080000	2026-08-31 22:02:54.272143+00
IPC	2026-04-01	11363.09040000	2026-08-31 22:02:54.272143+00
IPC	2026-05-01	11607.39370000	2026-08-31 22:02:54.272143+00
IPC	2026-06-01	11826.41030000	2026-08-31 22:02:54.272143+00
IPC	2026-07-01	12076.39370000	2026-08-31 22:02:54.272143+00
\.


--
-- Data for Name: inquilinos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inquilinos (id, nombre, documento, telefono, email, notas, deleted_at, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: liquidacion_detalle; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.liquidacion_detalle (id, liquidacion_id, contrato_id, tipo, cobro_id, gasto_id, descripcion, monto_bruto, honorarios_porcentaje, honorarios_monto, neto, orden) FROM stdin;
\.


--
-- Data for Name: liquidaciones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.liquidaciones (id, numero, propietario_id, periodo, moneda, total_cobrado, total_honorarios, total_gastos, total_ajustes, neto_a_pagar, estado, metodo_pago, fecha_pago, comprobante_url, conformidad, recibido_por, notas, emitida_at, emitida_por, anulado_at, anulado_motivo, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: perfiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.perfiles (id, nombre, email, rol, created_at) FROM stdin;
9a231ace-4d19-4956-a69f-f20558bfc11e	Alex Solórzano	alex.solorzano62@gmail.com	admin	2026-08-29 03:34:02.000511+00
\.


--
-- Data for Name: propiedades; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.propiedades (id, propietario_id, titulares_adicionales, direccion, piso_depto, localidad, provincia, tipo, ambientes, superficie_m2, partida_inmobiliaria, cuenta_luz, cuenta_gas, cuenta_agua, expensas_unidad, estado, notas, deleted_at, created_at, created_by, edificio) FROM stdin;
\.


--
-- Data for Name: propietarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.propietarios (id, nombre, documento, telefono, email, forma_cobro, cbu, alias_cbu, titular_cuenta, notas, deleted_at, created_at, created_by) FROM stdin;
\.


--
-- Name: liquidacion_numero_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.liquidacion_numero_seq', 1, false);


--
-- Name: recibo_numero_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recibo_numero_seq', 1, false);


--
-- Name: ajustes ajustes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ajustes
    ADD CONSTRAINT ajustes_pkey PRIMARY KEY (id);


--
-- Name: avisos_enviados avisos_enviados_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.avisos_enviados
    ADD CONSTRAINT avisos_enviados_pkey PRIMARY KEY (id);


--
-- Name: cobro_conceptos cobro_conceptos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cobro_conceptos
    ADD CONSTRAINT cobro_conceptos_pkey PRIMARY KEY (id);


--
-- Name: cobros cobros_numero_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cobros
    ADD CONSTRAINT cobros_numero_key UNIQUE (numero);


--
-- Name: cobros cobros_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cobros
    ADD CONSTRAINT cobros_pkey PRIMARY KEY (id);


--
-- Name: contratos contratos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contratos
    ADD CONSTRAINT contratos_pkey PRIMARY KEY (id);


--
-- Name: gastos gastos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_pkey PRIMARY KEY (id);


--
-- Name: indices_valores indices_valores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indices_valores
    ADD CONSTRAINT indices_valores_pkey PRIMARY KEY (indice, fecha);


--
-- Name: inquilinos inquilinos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inquilinos
    ADD CONSTRAINT inquilinos_pkey PRIMARY KEY (id);


--
-- Name: liquidacion_detalle liquidacion_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidacion_detalle
    ADD CONSTRAINT liquidacion_detalle_pkey PRIMARY KEY (id);


--
-- Name: liquidaciones liquidaciones_numero_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidaciones
    ADD CONSTRAINT liquidaciones_numero_key UNIQUE (numero);


--
-- Name: liquidaciones liquidaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidaciones
    ADD CONSTRAINT liquidaciones_pkey PRIMARY KEY (id);


--
-- Name: perfiles perfiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.perfiles
    ADD CONSTRAINT perfiles_pkey PRIMARY KEY (id);


--
-- Name: propiedades propiedades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.propiedades
    ADD CONSTRAINT propiedades_pkey PRIMARY KEY (id);


--
-- Name: propietarios propietarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.propietarios
    ADD CONSTRAINT propietarios_pkey PRIMARY KEY (id);


--
-- Name: ajustes_contrato_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ajustes_contrato_idx ON public.ajustes USING btree (contrato_id, fecha_aplicacion DESC);


--
-- Name: avisos_contrato_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX avisos_contrato_idx ON public.avisos_enviados USING btree (contrato_id, tipo, periodo DESC);


--
-- Name: avisos_liquidacion_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX avisos_liquidacion_idx ON public.avisos_enviados USING btree (liquidacion_id);


--
-- Name: cobro_conceptos_cobro_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cobro_conceptos_cobro_idx ON public.cobro_conceptos USING btree (cobro_id, orden);


--
-- Name: cobros_contrato_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cobros_contrato_idx ON public.cobros USING btree (contrato_id, periodo DESC);


--
-- Name: cobros_contrato_periodo_unico; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cobros_contrato_periodo_unico ON public.cobros USING btree (contrato_id, periodo) WHERE (anulado_at IS NULL);


--
-- Name: cobros_periodo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cobros_periodo_idx ON public.cobros USING btree (periodo DESC) WHERE (anulado_at IS NULL);


--
-- Name: contratos_activos_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contratos_activos_idx ON public.contratos USING btree (fecha_proximo_ajuste) WHERE ((estado = 'activo'::text) AND (deleted_at IS NULL));


--
-- Name: contratos_inquilino_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contratos_inquilino_idx ON public.contratos USING btree (inquilino_id);


--
-- Name: contratos_propiedad_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contratos_propiedad_idx ON public.contratos USING btree (propiedad_id);


--
-- Name: gastos_pendientes_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gastos_pendientes_idx ON public.gastos USING btree (a_cargo_de, fecha) WHERE ((cobro_id IS NULL) AND (liquidacion_id IS NULL) AND (deleted_at IS NULL));


--
-- Name: gastos_propiedad_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gastos_propiedad_idx ON public.gastos USING btree (propiedad_id, fecha DESC);


--
-- Name: indices_valores_fecha_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX indices_valores_fecha_idx ON public.indices_valores USING btree (indice, fecha DESC);


--
-- Name: inquilinos_activos_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inquilinos_activos_idx ON public.inquilinos USING btree (nombre) WHERE (deleted_at IS NULL);


--
-- Name: liquidacion_detalle_cobro_unico; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX liquidacion_detalle_cobro_unico ON public.liquidacion_detalle USING btree (cobro_id) WHERE (cobro_id IS NOT NULL);


--
-- Name: liquidacion_detalle_liq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX liquidacion_detalle_liq_idx ON public.liquidacion_detalle USING btree (liquidacion_id, orden);


--
-- Name: liquidaciones_propietario_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX liquidaciones_propietario_idx ON public.liquidaciones USING btree (propietario_id, periodo DESC);


--
-- Name: liquidaciones_propietario_periodo_unico; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX liquidaciones_propietario_periodo_unico ON public.liquidaciones USING btree (propietario_id, periodo, moneda) WHERE (anulado_at IS NULL);


--
-- Name: propiedades_edificio_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX propiedades_edificio_idx ON public.propiedades USING btree (edificio) WHERE ((deleted_at IS NULL) AND (edificio IS NOT NULL));


--
-- Name: propiedades_propietario_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX propiedades_propietario_idx ON public.propiedades USING btree (propietario_id) WHERE (deleted_at IS NULL);


--
-- Name: propietarios_activos_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX propietarios_activos_idx ON public.propietarios USING btree (nombre) WHERE (deleted_at IS NULL);


--
-- Name: cobro_conceptos cobro_conceptos_sin_borrado; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cobro_conceptos_sin_borrado BEFORE DELETE ON public.cobro_conceptos FOR EACH ROW EXECUTE FUNCTION public.prohibir_borrado();


--
-- Name: cobros cobros_inmutables_trg; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cobros_inmutables_trg BEFORE UPDATE ON public.cobros FOR EACH ROW EXECUTE FUNCTION public.cobros_inmutables();


--
-- Name: cobros cobros_sin_borrado; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cobros_sin_borrado BEFORE DELETE ON public.cobros FOR EACH ROW EXECUTE FUNCTION public.prohibir_borrado();


--
-- Name: liquidacion_detalle detalle_liquidacion_emitida_trg; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER detalle_liquidacion_emitida_trg BEFORE INSERT OR DELETE OR UPDATE ON public.liquidacion_detalle FOR EACH ROW EXECUTE FUNCTION public.detalle_liquidacion_emitida();


--
-- Name: liquidaciones liquidaciones_inmutables_trg; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER liquidaciones_inmutables_trg BEFORE UPDATE ON public.liquidaciones FOR EACH ROW EXECUTE FUNCTION public.liquidaciones_inmutables();


--
-- Name: liquidaciones liquidaciones_sin_borrado; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER liquidaciones_sin_borrado BEFORE DELETE ON public.liquidaciones FOR EACH ROW EXECUTE FUNCTION public.prohibir_borrado();


--
-- Name: ajustes ajustes_contrato_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ajustes
    ADD CONSTRAINT ajustes_contrato_id_fkey FOREIGN KEY (contrato_id) REFERENCES public.contratos(id);


--
-- Name: ajustes ajustes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ajustes
    ADD CONSTRAINT ajustes_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: avisos_enviados avisos_enviados_contrato_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.avisos_enviados
    ADD CONSTRAINT avisos_enviados_contrato_id_fkey FOREIGN KEY (contrato_id) REFERENCES public.contratos(id);


--
-- Name: avisos_enviados avisos_enviados_enviado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.avisos_enviados
    ADD CONSTRAINT avisos_enviados_enviado_por_fkey FOREIGN KEY (enviado_por) REFERENCES auth.users(id);


--
-- Name: avisos_enviados avisos_enviados_liquidacion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.avisos_enviados
    ADD CONSTRAINT avisos_enviados_liquidacion_id_fkey FOREIGN KEY (liquidacion_id) REFERENCES public.liquidaciones(id);


--
-- Name: cobro_conceptos cobro_conceptos_cobro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cobro_conceptos
    ADD CONSTRAINT cobro_conceptos_cobro_id_fkey FOREIGN KEY (cobro_id) REFERENCES public.cobros(id) ON DELETE CASCADE;


--
-- Name: cobros cobros_anulado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cobros
    ADD CONSTRAINT cobros_anulado_por_fkey FOREIGN KEY (anulado_por) REFERENCES auth.users(id);


--
-- Name: cobros cobros_contrato_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cobros
    ADD CONSTRAINT cobros_contrato_id_fkey FOREIGN KEY (contrato_id) REFERENCES public.contratos(id);


--
-- Name: cobros cobros_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cobros
    ADD CONSTRAINT cobros_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: contratos contratos_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contratos
    ADD CONSTRAINT contratos_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: contratos contratos_inquilino_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contratos
    ADD CONSTRAINT contratos_inquilino_id_fkey FOREIGN KEY (inquilino_id) REFERENCES public.inquilinos(id);


--
-- Name: contratos contratos_propiedad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contratos
    ADD CONSTRAINT contratos_propiedad_id_fkey FOREIGN KEY (propiedad_id) REFERENCES public.propiedades(id);


--
-- Name: gastos gastos_cobro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_cobro_id_fkey FOREIGN KEY (cobro_id) REFERENCES public.cobros(id);


--
-- Name: gastos gastos_contrato_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_contrato_id_fkey FOREIGN KEY (contrato_id) REFERENCES public.contratos(id);


--
-- Name: gastos gastos_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: gastos gastos_liquidacion_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_liquidacion_fk FOREIGN KEY (liquidacion_id) REFERENCES public.liquidaciones(id);


--
-- Name: gastos gastos_propiedad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_propiedad_id_fkey FOREIGN KEY (propiedad_id) REFERENCES public.propiedades(id);


--
-- Name: inquilinos inquilinos_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inquilinos
    ADD CONSTRAINT inquilinos_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: liquidacion_detalle liquidacion_detalle_cobro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidacion_detalle
    ADD CONSTRAINT liquidacion_detalle_cobro_id_fkey FOREIGN KEY (cobro_id) REFERENCES public.cobros(id);


--
-- Name: liquidacion_detalle liquidacion_detalle_contrato_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidacion_detalle
    ADD CONSTRAINT liquidacion_detalle_contrato_id_fkey FOREIGN KEY (contrato_id) REFERENCES public.contratos(id);


--
-- Name: liquidacion_detalle liquidacion_detalle_gasto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidacion_detalle
    ADD CONSTRAINT liquidacion_detalle_gasto_id_fkey FOREIGN KEY (gasto_id) REFERENCES public.gastos(id);


--
-- Name: liquidacion_detalle liquidacion_detalle_liquidacion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidacion_detalle
    ADD CONSTRAINT liquidacion_detalle_liquidacion_id_fkey FOREIGN KEY (liquidacion_id) REFERENCES public.liquidaciones(id) ON DELETE CASCADE;


--
-- Name: liquidaciones liquidaciones_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidaciones
    ADD CONSTRAINT liquidaciones_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: liquidaciones liquidaciones_emitida_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidaciones
    ADD CONSTRAINT liquidaciones_emitida_por_fkey FOREIGN KEY (emitida_por) REFERENCES auth.users(id);


--
-- Name: liquidaciones liquidaciones_propietario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidaciones
    ADD CONSTRAINT liquidaciones_propietario_id_fkey FOREIGN KEY (propietario_id) REFERENCES public.propietarios(id);


--
-- Name: perfiles perfiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.perfiles
    ADD CONSTRAINT perfiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: propiedades propiedades_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.propiedades
    ADD CONSTRAINT propiedades_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: propiedades propiedades_propietario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.propiedades
    ADD CONSTRAINT propiedades_propietario_id_fkey FOREIGN KEY (propietario_id) REFERENCES public.propietarios(id);


--
-- Name: propietarios propietarios_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.propietarios
    ADD CONSTRAINT propietarios_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: ajustes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ajustes ENABLE ROW LEVEL SECURITY;

--
-- Name: ajustes ajustes_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ajustes_insert ON public.ajustes FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: ajustes ajustes_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ajustes_select ON public.ajustes FOR SELECT USING (public.es_miembro());


--
-- Name: ajustes ajustes_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ajustes_update ON public.ajustes FOR UPDATE USING (public.es_miembro());


--
-- Name: avisos_enviados; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.avisos_enviados ENABLE ROW LEVEL SECURITY;

--
-- Name: avisos_enviados avisos_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY avisos_insert ON public.avisos_enviados FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: avisos_enviados avisos_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY avisos_select ON public.avisos_enviados FOR SELECT USING (public.es_miembro());


--
-- Name: cobro_conceptos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cobro_conceptos ENABLE ROW LEVEL SECURITY;

--
-- Name: cobro_conceptos cobro_conceptos_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cobro_conceptos_insert ON public.cobro_conceptos FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: cobro_conceptos cobro_conceptos_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cobro_conceptos_select ON public.cobro_conceptos FOR SELECT USING (public.es_miembro());


--
-- Name: cobros; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cobros ENABLE ROW LEVEL SECURITY;

--
-- Name: cobros cobros_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cobros_insert ON public.cobros FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: cobros cobros_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cobros_select ON public.cobros FOR SELECT USING (public.es_miembro());


--
-- Name: cobros cobros_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cobros_update ON public.cobros FOR UPDATE USING (public.es_admin());


--
-- Name: contratos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.contratos ENABLE ROW LEVEL SECURITY;

--
-- Name: contratos contratos_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contratos_insert ON public.contratos FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: contratos contratos_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contratos_select ON public.contratos FOR SELECT USING (public.es_miembro());


--
-- Name: contratos contratos_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contratos_update ON public.contratos FOR UPDATE USING (public.es_miembro());


--
-- Name: gastos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.gastos ENABLE ROW LEVEL SECURITY;

--
-- Name: gastos gastos_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY gastos_insert ON public.gastos FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: gastos gastos_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY gastos_select ON public.gastos FOR SELECT USING (public.es_miembro());


--
-- Name: gastos gastos_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY gastos_update ON public.gastos FOR UPDATE USING (public.es_miembro());


--
-- Name: indices_valores indices_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY indices_select ON public.indices_valores FOR SELECT USING (public.es_miembro());


--
-- Name: indices_valores; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.indices_valores ENABLE ROW LEVEL SECURITY;

--
-- Name: inquilinos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inquilinos ENABLE ROW LEVEL SECURITY;

--
-- Name: inquilinos inquilinos_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY inquilinos_insert ON public.inquilinos FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: inquilinos inquilinos_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY inquilinos_select ON public.inquilinos FOR SELECT USING (public.es_miembro());


--
-- Name: inquilinos inquilinos_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY inquilinos_update ON public.inquilinos FOR UPDATE USING (public.es_miembro());


--
-- Name: liquidacion_detalle; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.liquidacion_detalle ENABLE ROW LEVEL SECURITY;

--
-- Name: liquidacion_detalle liquidacion_detalle_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY liquidacion_detalle_delete ON public.liquidacion_detalle FOR DELETE USING (public.es_miembro());


--
-- Name: liquidacion_detalle liquidacion_detalle_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY liquidacion_detalle_insert ON public.liquidacion_detalle FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: liquidacion_detalle liquidacion_detalle_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY liquidacion_detalle_select ON public.liquidacion_detalle FOR SELECT USING (public.es_miembro());


--
-- Name: liquidaciones; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.liquidaciones ENABLE ROW LEVEL SECURITY;

--
-- Name: liquidaciones liquidaciones_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY liquidaciones_insert ON public.liquidaciones FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: liquidaciones liquidaciones_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY liquidaciones_select ON public.liquidaciones FOR SELECT USING (public.es_miembro());


--
-- Name: liquidaciones liquidaciones_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY liquidaciones_update ON public.liquidaciones FOR UPDATE USING (public.es_miembro());


--
-- Name: perfiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.perfiles ENABLE ROW LEVEL SECURITY;

--
-- Name: perfiles perfiles_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY perfiles_select ON public.perfiles FOR SELECT USING (((id = auth.uid()) OR public.es_admin()));


--
-- Name: perfiles perfiles_update_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY perfiles_update_admin ON public.perfiles FOR UPDATE USING (public.es_admin());


--
-- Name: propiedades; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.propiedades ENABLE ROW LEVEL SECURITY;

--
-- Name: propiedades propiedades_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY propiedades_insert ON public.propiedades FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: propiedades propiedades_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY propiedades_select ON public.propiedades FOR SELECT USING (public.es_miembro());


--
-- Name: propiedades propiedades_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY propiedades_update ON public.propiedades FOR UPDATE USING (public.es_miembro());


--
-- Name: propietarios; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.propietarios ENABLE ROW LEVEL SECURITY;

--
-- Name: propietarios propietarios_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY propietarios_insert ON public.propietarios FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: propietarios propietarios_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY propietarios_select ON public.propietarios FOR SELECT USING (public.es_miembro());


--
-- Name: propietarios propietarios_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY propietarios_update ON public.propietarios FOR UPDATE USING (public.es_miembro());


--
-- PostgreSQL database dump complete
--

\unrestrict auxbtU2fde59WjHauqvUAzWPwQ8AN9sftP3hMa9zIMZb1NbzFbrZICd5NG3AdkD

