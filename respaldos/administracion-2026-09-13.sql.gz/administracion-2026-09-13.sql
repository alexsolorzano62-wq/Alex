--
-- PostgreSQL database dump
--

\restrict mADGp7m70J7OFEkVqBwCTd3AT8riEbp9fXmUilPxVECccWtdpcmGOIqxUOjA0LA

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: cobros_inmutables(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cobros_inmutables() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if old.anulado_at is not null
     and new.anulado_at is not distinct from old.anulado_at then
    raise exception 'El recibo % está anulado: no se puede modificar.', old.numero;
  end if;

  if (new.numero, new.contrato_id, new.periodo, new.fecha_pago, new.total, new.moneda)
     is distinct from
     (old.numero, old.contrato_id, old.periodo, old.fecha_pago, old.total, old.moneda)
  then
    raise exception
      'Un recibo emitido no se edita. Anulá el recibo % y emití uno nuevo.',
      old.numero;
  end if;

  return new;
end;
$$;


--
-- Name: detalle_liquidacion_emitida(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.detalle_liquidacion_emitida() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
  emitida timestamptz;
  liq_id uuid;
begin
  liq_id := coalesce(new.liquidacion_id, old.liquidacion_id);
  select l.emitida_at into emitida
    from public.liquidaciones l where l.id = liq_id;

  if emitida is not null then
    raise exception 'La liquidación ya fue emitida: su detalle no se modifica.';
  end if;

  return coalesce(new, old);
end;
$$;


--
-- Name: es_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.es_admin() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select coalesce(
    (select rol = 'admin' from public.perfiles where id = auth.uid()),
    false
  );
$$;


--
-- Name: es_miembro(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.es_miembro() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select exists (select 1 from public.perfiles where id = auth.uid());
$$;


--
-- Name: liquidaciones_inmutables(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.liquidaciones_inmutables() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if old.emitida_at is null then
    return new;                          -- todavía es borrador: se edita libre
  end if;

  if (new.propietario_id, new.periodo, new.moneda,
      new.total_cobrado, new.total_honorarios, new.total_gastos,
      new.total_ajustes, new.neto_a_pagar)
     is distinct from
     (old.propietario_id, old.periodo, old.moneda,
      old.total_cobrado, old.total_honorarios, old.total_gastos,
      old.total_ajustes, old.neto_a_pagar)
  then
    raise exception
      'La liquidación % ya fue emitida: sus números no se modifican. Anulala y emití una nueva.',
      old.numero;
  end if;

  return new;
end;
$$;


--
-- Name: prohibir_borrado(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prohibir_borrado() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  raise exception
    'Esta tabla no admite borrado: anulá el registro para conservar el historial.';
end;
$$;


--
-- Name: tareas_sellar_completada(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tareas_sellar_completada() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if new.estado = 'hecha' and old.estado is distinct from 'hecha' then
    new.completada_at := coalesce(new.completada_at, now());
    new.completada_por := coalesce(new.completada_por, auth.uid());
  elsif new.estado = 'pendiente' then
    new.completada_at := null;
    new.completada_por := null;
  end if;
  return new;
end;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ajustes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ajustes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    contrato_id uuid NOT NULL,
    fecha_aplicacion date NOT NULL,
    periodo_desde date NOT NULL,
    periodo_hasta date NOT NULL,
    indice text NOT NULL,
    valor_indice_base numeric(20,8),
    valor_indice_final numeric(20,8),
    coeficiente numeric(12,6) NOT NULL,
    monto_anterior numeric(14,2) NOT NULL,
    monto_nuevo numeric(14,2) NOT NULL,
    notificado_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT ajustes_coeficiente_check CHECK ((coeficiente > (0)::numeric))
);


--
-- Name: avisos_enviados; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.avisos_enviados (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tipo text NOT NULL,
    contrato_id uuid,
    liquidacion_id uuid,
    periodo date,
    destino text,
    enviado_at timestamp with time zone DEFAULT now() NOT NULL,
    enviado_por uuid,
    CONSTRAINT avisos_cuelgan_de_algo CHECK (((contrato_id IS NOT NULL) OR (liquidacion_id IS NOT NULL))),
    CONSTRAINT avisos_enviados_tipo_check CHECK ((tipo = ANY (ARRAY['vencimiento'::text, 'aumento'::text, 'liquidacion'::text, 'recibo'::text])))
);


--
-- Name: cobro_conceptos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cobro_conceptos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    cobro_id uuid NOT NULL,
    tipo text NOT NULL,
    descripcion text,
    monto numeric(14,2) NOT NULL,
    orden integer DEFAULT 0 NOT NULL,
    CONSTRAINT cobro_conceptos_tipo_check CHECK ((tipo = ANY (ARRAY['alquiler'::text, 'expensas'::text, 'abl'::text, 'luz'::text, 'gas'::text, 'agua'::text, 'punitorios'::text, 'reparacion'::text, 'ajuste_manual'::text, 'saldo_anterior'::text, 'otro'::text])))
);


--
-- Name: recibo_numero_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recibo_numero_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cobros; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cobros (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    numero bigint DEFAULT nextval('public.recibo_numero_seq'::regclass) NOT NULL,
    contrato_id uuid NOT NULL,
    periodo date NOT NULL,
    fecha_pago date NOT NULL,
    vencimiento date NOT NULL,
    moneda text DEFAULT 'ARS'::text NOT NULL,
    total numeric(14,2) NOT NULL,
    medio_pago text DEFAULT 'transferencia'::text NOT NULL,
    comprobante_url text,
    notas text,
    emisiones integer DEFAULT 1 NOT NULL,
    anulado_at timestamp with time zone,
    anulado_motivo text,
    anulado_por uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    saldo_anterior numeric(14,2) DEFAULT 0 NOT NULL,
    saldo_resultante numeric(14,2) DEFAULT 0 NOT NULL,
    CONSTRAINT cobros_anulacion_con_motivo CHECK (((anulado_at IS NULL) OR (anulado_motivo IS NOT NULL))),
    CONSTRAINT cobros_emisiones_check CHECK ((emisiones >= 1)),
    CONSTRAINT cobros_medio_pago_check CHECK ((medio_pago = ANY (ARRAY['transferencia'::text, 'efectivo'::text, 'cheque'::text, 'deposito'::text, 'otro'::text]))),
    CONSTRAINT cobros_moneda_check CHECK ((moneda = ANY (ARRAY['ARS'::text, 'USD'::text]))),
    CONSTRAINT cobros_periodo_dia_1 CHECK ((EXTRACT(day FROM periodo) = (1)::numeric)),
    CONSTRAINT cobros_total_check CHECK ((total >= (0)::numeric))
);


--
-- Name: COLUMN cobros.saldo_anterior; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cobros.saldo_anterior IS 'Saldo con el que llegaba el inquilino. Positivo: a favor. Negativo: debe.';


--
-- Name: COLUMN cobros.saldo_resultante; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cobros.saldo_resultante IS 'Saldo que queda después de este recibo, con el mismo signo.';


--
-- Name: conceptos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conceptos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    nombre text NOT NULL,
    tipo text DEFAULT 'otro'::text NOT NULL,
    detalle text,
    activo boolean DEFAULT true NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT conceptos_nombre_check CHECK ((length(TRIM(BOTH FROM nombre)) > 0)),
    CONSTRAINT conceptos_tipo_check CHECK ((tipo = ANY (ARRAY['expensas'::text, 'abl'::text, 'luz'::text, 'gas'::text, 'agua'::text, 'otro'::text])))
);


--
-- Name: contrato_cargos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contrato_cargos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    contrato_id uuid NOT NULL,
    tipo text DEFAULT 'otro'::text NOT NULL,
    descripcion text NOT NULL,
    monto numeric(14,2) NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    concepto_id uuid,
    CONSTRAINT contrato_cargos_monto_check CHECK ((monto > (0)::numeric)),
    CONSTRAINT contrato_cargos_tipo_check CHECK ((tipo = ANY (ARRAY['expensas'::text, 'abl'::text, 'luz'::text, 'gas'::text, 'agua'::text, 'otro'::text])))
);


--
-- Name: contratos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contratos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    propiedad_id uuid NOT NULL,
    inquilino_id uuid NOT NULL,
    garantes text,
    fecha_inicio date NOT NULL,
    fecha_fin date NOT NULL,
    destino text DEFAULT 'vivienda'::text NOT NULL,
    moneda text DEFAULT 'ARS'::text NOT NULL,
    monto_inicial numeric(14,2) NOT NULL,
    monto_actual numeric(14,2) NOT NULL,
    deposito_monto numeric(14,2),
    deposito_estado text DEFAULT 'retenido'::text NOT NULL,
    dia_vencimiento integer DEFAULT 10 NOT NULL,
    honorarios_porcentaje numeric(5,2) DEFAULT 8 NOT NULL,
    indice text DEFAULT 'ICL'::text NOT NULL,
    ajuste_frecuencia_meses integer DEFAULT 3 NOT NULL,
    ajuste_porcentaje_fijo numeric(6,3),
    fecha_ultimo_ajuste date,
    fecha_proximo_ajuste date,
    punitorio_tipo text DEFAULT 'porcentaje_diario'::text NOT NULL,
    punitorio_valor numeric(10,4) DEFAULT 0 NOT NULL,
    punitorio_dias_gracia integer DEFAULT 0 NOT NULL,
    estado text DEFAULT 'activo'::text NOT NULL,
    observaciones text,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT contratos_ajuste_fijo CHECK (((indice <> 'FIJO'::text) OR (ajuste_porcentaje_fijo IS NOT NULL))),
    CONSTRAINT contratos_ajuste_frecuencia_meses_check CHECK (((ajuste_frecuencia_meses >= 1) AND (ajuste_frecuencia_meses <= 36))),
    CONSTRAINT contratos_deposito_estado_check CHECK ((deposito_estado = ANY (ARRAY['retenido'::text, 'devuelto'::text, 'aplicado'::text, 'sin_deposito'::text]))),
    CONSTRAINT contratos_destino_check CHECK ((destino = ANY (ARRAY['vivienda'::text, 'comercial'::text, 'mixto'::text, 'otro'::text]))),
    CONSTRAINT contratos_dia_vencimiento_check CHECK (((dia_vencimiento >= 1) AND (dia_vencimiento <= 28))),
    CONSTRAINT contratos_estado_check CHECK ((estado = ANY (ARRAY['activo'::text, 'finalizado'::text, 'rescindido'::text]))),
    CONSTRAINT contratos_fechas CHECK ((fecha_fin > fecha_inicio)),
    CONSTRAINT contratos_honorarios_porcentaje_check CHECK (((honorarios_porcentaje >= (0)::numeric) AND (honorarios_porcentaje <= (100)::numeric))),
    CONSTRAINT contratos_indice_check CHECK ((indice = ANY (ARRAY['ICL'::text, 'IPC'::text, 'UVA'::text, 'CASA_PROPIA'::text, 'FIJO'::text, 'SIN_AJUSTE'::text]))),
    CONSTRAINT contratos_moneda_check CHECK ((moneda = ANY (ARRAY['ARS'::text, 'USD'::text]))),
    CONSTRAINT contratos_monto_actual_check CHECK ((monto_actual > (0)::numeric)),
    CONSTRAINT contratos_monto_inicial_check CHECK ((monto_inicial > (0)::numeric)),
    CONSTRAINT contratos_punitorio_dias_gracia_check CHECK ((punitorio_dias_gracia >= 0)),
    CONSTRAINT contratos_punitorio_tipo_check CHECK ((punitorio_tipo = ANY (ARRAY['porcentaje_diario'::text, 'monto_fijo_diario'::text, 'ninguno'::text]))),
    CONSTRAINT contratos_punitorio_valor_check CHECK ((punitorio_valor >= (0)::numeric))
);


--
-- Name: feriados; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feriados (
    fecha date NOT NULL,
    nombre text NOT NULL,
    origen text DEFAULT 'fijo'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT feriados_origen_check CHECK ((origen = ANY (ARRAY['fijo'::text, 'movible'::text])))
);


--
-- Name: gastos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gastos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    propiedad_id uuid NOT NULL,
    contrato_id uuid,
    fecha date NOT NULL,
    tipo text DEFAULT 'otro'::text NOT NULL,
    descripcion text NOT NULL,
    monto numeric(14,2) NOT NULL,
    moneda text DEFAULT 'ARS'::text NOT NULL,
    a_cargo_de text DEFAULT 'propietario'::text NOT NULL,
    comprobante_url text,
    notas text,
    cobro_id uuid,
    liquidacion_id uuid,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT gastos_a_cargo_de_check CHECK ((a_cargo_de = ANY (ARRAY['propietario'::text, 'inquilino'::text]))),
    CONSTRAINT gastos_moneda_check CHECK ((moneda = ANY (ARRAY['ARS'::text, 'USD'::text]))),
    CONSTRAINT gastos_monto_check CHECK ((monto > (0)::numeric)),
    CONSTRAINT gastos_tipo_check CHECK ((tipo = ANY (ARRAY['expensas'::text, 'abl'::text, 'luz'::text, 'gas'::text, 'agua'::text, 'reparacion'::text, 'seguro'::text, 'honorarios_profesionales'::text, 'impuesto'::text, 'otro'::text])))
);


--
-- Name: indices_valores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indices_valores (
    indice text NOT NULL,
    fecha date NOT NULL,
    valor numeric(20,8) NOT NULL,
    actualizado_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT indices_valores_indice_check CHECK ((indice = ANY (ARRAY['ICL'::text, 'IPC'::text, 'UVA'::text, 'CASA_PROPIA'::text]))),
    CONSTRAINT indices_valores_valor_check CHECK ((valor > (0)::numeric))
);


--
-- Name: inquilinos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inquilinos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    nombre text NOT NULL,
    documento text,
    telefono text,
    email text,
    notas text,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid
);


--
-- Name: liquidacion_detalle; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.liquidacion_detalle (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    liquidacion_id uuid NOT NULL,
    contrato_id uuid,
    tipo text NOT NULL,
    cobro_id uuid,
    gasto_id uuid,
    descripcion text NOT NULL,
    monto_bruto numeric(14,2) NOT NULL,
    honorarios_porcentaje numeric(5,2),
    honorarios_monto numeric(14,2) DEFAULT 0 NOT NULL,
    neto numeric(14,2) NOT NULL,
    orden integer DEFAULT 0 NOT NULL,
    CONSTRAINT liquidacion_detalle_tipo_check CHECK ((tipo = ANY (ARRAY['cobro'::text, 'gasto'::text, 'ajuste'::text])))
);


--
-- Name: liquidacion_numero_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.liquidacion_numero_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: liquidaciones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.liquidaciones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    numero bigint DEFAULT nextval('public.liquidacion_numero_seq'::regclass) NOT NULL,
    propietario_id uuid NOT NULL,
    periodo date NOT NULL,
    moneda text DEFAULT 'ARS'::text NOT NULL,
    total_cobrado numeric(14,2) DEFAULT 0 NOT NULL,
    total_honorarios numeric(14,2) DEFAULT 0 NOT NULL,
    total_gastos numeric(14,2) DEFAULT 0 NOT NULL,
    total_ajustes numeric(14,2) DEFAULT 0 NOT NULL,
    neto_a_pagar numeric(14,2) DEFAULT 0 NOT NULL,
    estado text DEFAULT 'borrador'::text NOT NULL,
    metodo_pago text,
    fecha_pago date,
    comprobante_url text,
    conformidad text,
    recibido_por text,
    notas text,
    emitida_at timestamp with time zone,
    emitida_por uuid,
    anulado_at timestamp with time zone,
    anulado_motivo text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT liquidaciones_estado_check CHECK ((estado = ANY (ARRAY['borrador'::text, 'emitida'::text, 'pagada'::text, 'anulada'::text]))),
    CONSTRAINT liquidaciones_metodo_pago_check CHECK ((metodo_pago = ANY (ARRAY['transferencia'::text, 'efectivo'::text]))),
    CONSTRAINT liquidaciones_moneda_check CHECK ((moneda = ANY (ARRAY['ARS'::text, 'USD'::text]))),
    CONSTRAINT liquidaciones_pagada_completa CHECK (((estado <> 'pagada'::text) OR ((metodo_pago IS NOT NULL) AND (fecha_pago IS NOT NULL)))),
    CONSTRAINT liquidaciones_periodo_dia_1 CHECK ((EXTRACT(day FROM periodo) = (1)::numeric))
);


--
-- Name: perfiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.perfiles (
    id uuid NOT NULL,
    nombre text NOT NULL,
    email text NOT NULL,
    rol text DEFAULT 'operador'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT perfiles_rol_check CHECK ((rol = ANY (ARRAY['operador'::text, 'admin'::text])))
);


--
-- Name: propiedades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.propiedades (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    propietario_id uuid NOT NULL,
    titulares_adicionales text,
    direccion text NOT NULL,
    piso_depto text,
    localidad text,
    provincia text DEFAULT 'Buenos Aires'::text,
    tipo text DEFAULT 'departamento'::text NOT NULL,
    ambientes integer,
    superficie_m2 numeric(10,2),
    partida_inmobiliaria text,
    cuenta_luz text,
    cuenta_gas text,
    cuenta_agua text,
    expensas_unidad text,
    estado text DEFAULT 'alquilado'::text NOT NULL,
    notas text,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    edificio text,
    CONSTRAINT propiedades_estado_check CHECK ((estado = ANY (ARRAY['alquilado'::text, 'disponible'::text, 'en_refaccion'::text, 'retirado'::text]))),
    CONSTRAINT propiedades_tipo_check CHECK ((tipo = ANY (ARRAY['departamento'::text, 'casa'::text, 'ph'::text, 'monoambiente'::text, 'duplex'::text, 'local'::text, 'oficina'::text, 'galpon'::text, 'cochera'::text, 'terreno'::text, 'otro'::text])))
);


--
-- Name: COLUMN propiedades.edificio; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.propiedades.edificio IS 'Nombre del edificio. Si está vacío, la unidad se agrupa por su dirección.';


--
-- Name: propietarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.propietarios (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    nombre text NOT NULL,
    documento text,
    telefono text,
    email text,
    forma_cobro text DEFAULT 'transferencia'::text NOT NULL,
    cbu text,
    alias_cbu text,
    titular_cuenta text,
    notas text,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT propietarios_forma_cobro_check CHECK ((forma_cobro = ANY (ARRAY['transferencia'::text, 'efectivo'::text])))
);


--
-- Name: tareas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tareas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    titulo text NOT NULL,
    detalle text,
    estado text DEFAULT 'pendiente'::text NOT NULL,
    prioridad text DEFAULT 'normal'::text NOT NULL,
    vence_el date,
    propiedad_id uuid,
    contrato_id uuid,
    inquilino_id uuid,
    completada_at timestamp with time zone,
    completada_por uuid,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT tareas_estado_check CHECK ((estado = ANY (ARRAY['pendiente'::text, 'hecha'::text]))),
    CONSTRAINT tareas_estado_coherente CHECK ((((estado = 'hecha'::text) AND (completada_at IS NOT NULL)) OR ((estado = 'pendiente'::text) AND (completada_at IS NULL)))),
    CONSTRAINT tareas_prioridad_check CHECK ((prioridad = ANY (ARRAY['baja'::text, 'normal'::text, 'alta'::text]))),
    CONSTRAINT tareas_titulo_check CHECK ((length(TRIM(BOTH FROM titulo)) > 0))
);


--
-- Data for Name: ajustes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ajustes (id, contrato_id, fecha_aplicacion, periodo_desde, periodo_hasta, indice, valor_indice_base, valor_indice_final, coeficiente, monto_anterior, monto_nuevo, notificado_at, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: avisos_enviados; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.avisos_enviados (id, tipo, contrato_id, liquidacion_id, periodo, destino, enviado_at, enviado_por) FROM stdin;
\.


--
-- Data for Name: cobro_conceptos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cobro_conceptos (id, cobro_id, tipo, descripcion, monto, orden) FROM stdin;
\.


--
-- Data for Name: cobros; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cobros (id, numero, contrato_id, periodo, fecha_pago, vencimiento, moneda, total, medio_pago, comprobante_url, notas, emisiones, anulado_at, anulado_motivo, anulado_por, created_at, created_by, saldo_anterior, saldo_resultante) FROM stdin;
\.


--
-- Data for Name: conceptos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conceptos (id, nombre, tipo, detalle, activo, deleted_at, created_at, created_by) FROM stdin;
0ca82fc4-63cb-477e-9bb4-8d147e80687f	SAT	agua	Agua — Sociedad Aguas del Tucumán	t	\N	2026-09-04 20:26:51.383962+00	\N
0fb431a6-957c-4570-afff-af5de03bb638	EDET	luz	Luz — Empresa de Distribución Eléctrica de Tucumán	t	\N	2026-09-04 20:26:51.383962+00	\N
613af989-61e1-49ba-af8b-3b02d3f627a6	CISI	abl	Contribución municipal	t	\N	2026-09-04 20:26:51.383962+00	\N
7da43f43-67f0-4c54-b1d0-afdd603ddbbf	Expensas	expensas	Expensas ordinarias	t	\N	2026-09-04 20:26:51.383962+00	\N
0c2a4ee7-1331-49c7-b65d-a739e7594430	Naturgy	gas	Gas natural	t	\N	2026-09-04 20:26:51.383962+00	\N
\.


--
-- Data for Name: contrato_cargos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contrato_cargos (id, contrato_id, tipo, descripcion, monto, activo, deleted_at, created_at, created_by, concepto_id) FROM stdin;
\.


--
-- Data for Name: contratos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contratos (id, propiedad_id, inquilino_id, garantes, fecha_inicio, fecha_fin, destino, moneda, monto_inicial, monto_actual, deposito_monto, deposito_estado, dia_vencimiento, honorarios_porcentaje, indice, ajuste_frecuencia_meses, ajuste_porcentaje_fijo, fecha_ultimo_ajuste, fecha_proximo_ajuste, punitorio_tipo, punitorio_valor, punitorio_dias_gracia, estado, observaciones, deleted_at, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: feriados; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feriados (fecha, nombre, origen, created_at, created_by) FROM stdin;
2026-01-01	Año Nuevo	fijo	2026-09-04 14:38:51.443281+00	\N
2026-03-24	Día de la Memoria	fijo	2026-09-04 14:38:51.443281+00	\N
2026-04-02	Día del Veterano y de los Caídos en Malvinas	fijo	2026-09-04 14:38:51.443281+00	\N
2026-05-01	Día del Trabajador	fijo	2026-09-04 14:38:51.443281+00	\N
2026-05-25	Día de la Revolución de Mayo	fijo	2026-09-04 14:38:51.443281+00	\N
2026-06-20	Paso a la Inmortalidad del General Belgrano	fijo	2026-09-04 14:38:51.443281+00	\N
2026-07-09	Día de la Independencia	fijo	2026-09-04 14:38:51.443281+00	\N
2026-12-08	Inmaculada Concepción de María	fijo	2026-09-04 14:38:51.443281+00	\N
2026-12-25	Navidad	fijo	2026-09-04 14:38:51.443281+00	\N
2027-01-01	Año Nuevo	fijo	2026-09-04 14:38:51.443281+00	\N
2027-03-24	Día de la Memoria	fijo	2026-09-04 14:38:51.443281+00	\N
2027-04-02	Día del Veterano y de los Caídos en Malvinas	fijo	2026-09-04 14:38:51.443281+00	\N
2027-05-01	Día del Trabajador	fijo	2026-09-04 14:38:51.443281+00	\N
2027-05-25	Día de la Revolución de Mayo	fijo	2026-09-04 14:38:51.443281+00	\N
2027-06-20	Paso a la Inmortalidad del General Belgrano	fijo	2026-09-04 14:38:51.443281+00	\N
2027-07-09	Día de la Independencia	fijo	2026-09-04 14:38:51.443281+00	\N
2027-12-08	Inmaculada Concepción de María	fijo	2026-09-04 14:38:51.443281+00	\N
2027-12-25	Navidad	fijo	2026-09-04 14:38:51.443281+00	\N
2028-01-01	Año Nuevo	fijo	2026-09-04 14:38:51.443281+00	\N
2028-03-24	Día de la Memoria	fijo	2026-09-04 14:38:51.443281+00	\N
2028-04-02	Día del Veterano y de los Caídos en Malvinas	fijo	2026-09-04 14:38:51.443281+00	\N
2028-05-01	Día del Trabajador	fijo	2026-09-04 14:38:51.443281+00	\N
2028-05-25	Día de la Revolución de Mayo	fijo	2026-09-04 14:38:51.443281+00	\N
2028-06-20	Paso a la Inmortalidad del General Belgrano	fijo	2026-09-04 14:38:51.443281+00	\N
2028-07-09	Día de la Independencia	fijo	2026-09-04 14:38:51.443281+00	\N
2028-12-08	Inmaculada Concepción de María	fijo	2026-09-04 14:38:51.443281+00	\N
2028-12-25	Navidad	fijo	2026-09-04 14:38:51.443281+00	\N
2029-01-01	Año Nuevo	fijo	2026-09-04 14:38:51.443281+00	\N
2029-03-24	Día de la Memoria	fijo	2026-09-04 14:38:51.443281+00	\N
2029-04-02	Día del Veterano y de los Caídos en Malvinas	fijo	2026-09-04 14:38:51.443281+00	\N
2029-05-01	Día del Trabajador	fijo	2026-09-04 14:38:51.443281+00	\N
2029-05-25	Día de la Revolución de Mayo	fijo	2026-09-04 14:38:51.443281+00	\N
2029-06-20	Paso a la Inmortalidad del General Belgrano	fijo	2026-09-04 14:38:51.443281+00	\N
2029-07-09	Día de la Independencia	fijo	2026-09-04 14:38:51.443281+00	\N
2029-12-08	Inmaculada Concepción de María	fijo	2026-09-04 14:38:51.443281+00	\N
2029-12-25	Navidad	fijo	2026-09-04 14:38:51.443281+00	\N
2030-01-01	Año Nuevo	fijo	2026-09-04 14:38:51.443281+00	\N
2030-03-24	Día de la Memoria	fijo	2026-09-04 14:38:51.443281+00	\N
2030-04-02	Día del Veterano y de los Caídos en Malvinas	fijo	2026-09-04 14:38:51.443281+00	\N
2030-05-01	Día del Trabajador	fijo	2026-09-04 14:38:51.443281+00	\N
2030-05-25	Día de la Revolución de Mayo	fijo	2026-09-04 14:38:51.443281+00	\N
2030-06-20	Paso a la Inmortalidad del General Belgrano	fijo	2026-09-04 14:38:51.443281+00	\N
2030-07-09	Día de la Independencia	fijo	2026-09-04 14:38:51.443281+00	\N
2030-12-08	Inmaculada Concepción de María	fijo	2026-09-04 14:38:51.443281+00	\N
2030-12-25	Navidad	fijo	2026-09-04 14:38:51.443281+00	\N
\.


--
-- Data for Name: gastos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gastos (id, propiedad_id, contrato_id, fecha, tipo, descripcion, monto, moneda, a_cargo_de, comprobante_url, notas, cobro_id, liquidacion_id, deleted_at, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: indices_valores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indices_valores (indice, fecha, valor, actualizado_at) FROM stdin;
ICL	2026-09-16	36.21000000	2026-09-02 03:19:25.987378+00
ICL	2026-09-15	36.18000000	2026-09-02 03:19:25.987378+00
ICL	2026-09-14	36.15000000	2026-09-02 03:19:25.987378+00
ICL	2026-09-13	36.12000000	2026-09-02 03:19:25.987378+00
ICL	2026-09-12	36.08000000	2026-09-02 03:19:25.987378+00
ICL	2026-09-11	36.05000000	2026-09-02 03:19:25.987378+00
ICL	2026-09-10	36.02000000	2026-09-02 03:19:25.987378+00
ICL	2026-09-09	35.99000000	2026-09-02 03:19:25.987378+00
ICL	2026-09-08	35.96000000	2026-09-02 03:19:25.987378+00
ICL	2026-09-07	35.93000000	2026-09-02 03:19:25.987378+00
ICL	2026-09-06	35.90000000	2026-09-02 03:19:25.987378+00
ICL	2026-09-05	35.87000000	2026-09-02 03:19:25.987378+00
ICL	2026-09-04	35.83000000	2026-09-02 03:19:25.987378+00
ICL	2026-09-03	35.80000000	2026-09-02 03:19:25.987378+00
ICL	2026-09-02	35.77000000	2026-09-02 03:19:25.987378+00
ICL	2026-09-01	35.74000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-31	35.71000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-30	35.68000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-29	35.65000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-28	35.62000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-27	35.59000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-26	35.56000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-25	35.52000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-24	35.49000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-23	35.46000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-22	35.43000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-21	35.40000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-20	35.37000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-19	35.34000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-18	35.31000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-17	35.28000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-16	35.25000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-15	35.23000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-14	35.22000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-13	35.20000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-12	35.18000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-11	35.17000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-10	35.15000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-09	35.14000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-08	35.12000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-07	35.11000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-06	35.09000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-05	35.07000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-04	35.06000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-03	35.04000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-02	35.03000000	2026-09-02 03:19:25.987378+00
ICL	2026-08-01	35.01000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-31	34.99000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-30	34.98000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-29	34.96000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-28	34.95000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-27	34.93000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-26	34.92000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-25	34.90000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-24	34.88000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-23	34.87000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-22	34.85000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-21	34.84000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-20	34.82000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-19	34.81000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-18	34.79000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-17	34.77000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-16	34.76000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-15	34.72000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-14	34.69000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-13	34.66000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-12	34.62000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-11	34.59000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-10	34.55000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-09	34.52000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-08	34.48000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-07	34.45000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-06	34.41000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-05	34.38000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-26	30.52000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-25	30.49000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-24	30.47000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-23	30.45000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-22	30.43000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-21	30.40000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-20	30.38000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-19	30.36000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-18	30.34000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-17	30.31000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-16	30.29000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-15	30.27000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-14	30.26000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-13	30.24000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-12	30.22000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-11	30.20000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-10	30.18000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-09	30.17000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-08	30.15000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-07	30.13000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-06	30.11000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-05	30.10000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-04	30.08000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-03	30.06000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-02	30.04000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-01	30.03000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-31	30.01000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-30	29.99000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-29	29.97000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-28	29.96000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-27	29.94000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-26	29.92000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-25	29.90000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-24	29.89000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-23	29.87000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-22	29.85000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-21	29.83000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-20	29.82000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-19	29.80000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-18	29.78000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-17	29.76000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-16	29.75000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-15	29.72000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-14	29.70000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-13	29.68000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-12	29.65000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-11	29.63000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-10	29.61000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-09	29.58000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-08	29.56000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-07	29.54000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-06	29.51000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-05	29.49000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-04	29.46000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-03	29.44000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-02	29.42000000	2026-09-02 03:19:25.987378+00
ICL	2026-01-01	29.39000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-31	29.37000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-30	29.35000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-29	29.32000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-28	29.30000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-27	29.28000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-26	29.25000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-25	29.23000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-24	29.21000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-23	29.18000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-22	29.16000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-21	29.14000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-20	29.11000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-19	29.09000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-18	29.07000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-17	29.05000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-16	29.02000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-15	29.01000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-14	28.99000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-13	28.97000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-12	28.96000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-11	28.94000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-10	28.92000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-09	28.91000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-08	28.89000000	2026-09-02 03:19:25.987378+00
IPC	2020-07-01	328.20140000	2026-08-31 22:02:54.272143+00
IPC	2020-08-01	337.06320000	2026-08-31 22:02:54.272143+00
IPC	2020-09-01	346.62070000	2026-08-31 22:02:54.272143+00
IPC	2020-10-01	359.65700000	2026-08-31 22:02:54.272143+00
IPC	2020-11-01	371.02110000	2026-08-31 22:02:54.272143+00
IPC	2020-12-01	385.88260000	2026-08-31 22:02:54.272143+00
IPC	2026-02-01	10714.62550000	2026-08-31 22:02:54.272143+00
IPC	2026-03-01	11077.06080000	2026-08-31 22:02:54.272143+00
IPC	2026-04-01	11363.09040000	2026-08-31 22:02:54.272143+00
IPC	2026-05-01	11607.39370000	2026-08-31 22:02:54.272143+00
IPC	2026-06-01	11826.41030000	2026-08-31 22:02:54.272143+00
IPC	2026-07-01	12076.39370000	2026-08-31 22:02:54.272143+00
ICL	2026-04-26	31.92000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-25	31.88000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-24	31.83000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-23	31.79000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-22	31.75000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-21	31.71000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-20	31.66000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-19	31.62000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-18	31.58000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-17	31.53000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-16	31.49000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-15	31.47000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-14	31.46000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-13	31.44000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-12	31.42000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-11	31.40000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-10	31.38000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-09	31.36000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-08	31.35000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-07	31.33000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-06	31.31000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-05	31.29000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-04	31.27000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-03	31.25000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-02	31.24000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-01	31.22000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-31	31.20000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-30	31.18000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-29	31.16000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-28	31.14000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-27	31.13000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-26	31.11000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-25	31.09000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-24	31.07000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-23	31.05000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-22	31.03000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-21	31.02000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-20	31.00000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-19	30.98000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-18	30.96000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-17	30.94000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-16	30.93000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-15	30.90000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-14	30.88000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-13	30.86000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-12	30.83000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-11	30.81000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-10	30.79000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-09	30.77000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-08	30.74000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-07	30.72000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-06	30.70000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-05	30.67000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-04	30.65000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-03	30.63000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-02	30.61000000	2026-09-02 03:19:25.987378+00
ICL	2026-03-01	30.58000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-28	30.56000000	2026-09-02 03:19:25.987378+00
ICL	2026-02-27	30.54000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-07	28.87000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-06	28.86000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-05	28.84000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-04	28.82000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-03	28.81000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-02	28.79000000	2026-09-02 03:19:25.987378+00
ICL	2025-12-01	28.77000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-30	28.76000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-29	28.74000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-28	28.72000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-27	28.71000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-26	28.69000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-25	28.67000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-24	28.66000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-23	28.64000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-22	28.62000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-21	28.61000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-20	28.59000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-19	28.57000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-18	28.56000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-04	34.35000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-03	34.31000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-02	34.28000000	2026-09-02 03:19:25.987378+00
ICL	2026-07-01	34.24000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-30	34.21000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-29	34.18000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-28	34.14000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-27	34.11000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-26	34.07000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-25	34.04000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-24	34.01000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-23	33.97000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-22	33.94000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-21	33.90000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-20	33.87000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-19	33.84000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-18	33.80000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-17	33.77000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-16	33.74000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-15	33.70000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-14	33.67000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-13	33.64000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-12	33.61000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-11	33.58000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-10	33.55000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-09	33.52000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-08	33.49000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-07	33.46000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-06	33.43000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-05	33.40000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-04	33.37000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-03	33.34000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-02	33.31000000	2026-09-02 03:19:25.987378+00
ICL	2026-06-01	33.27000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-31	33.24000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-30	33.21000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-29	33.18000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-28	33.15000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-27	33.12000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-26	33.09000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-25	33.06000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-24	33.03000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-23	33.00000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-22	32.97000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-21	32.94000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-20	32.91000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-19	32.88000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-18	32.85000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-17	32.82000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-16	32.79000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-15	32.75000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-14	32.70000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-13	32.66000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-12	32.61000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-11	32.57000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-10	32.53000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-09	32.48000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-08	32.44000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-07	32.40000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-06	32.35000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-05	32.31000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-04	32.26000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-03	32.22000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-02	32.18000000	2026-09-02 03:19:25.987378+00
ICL	2026-05-01	32.13000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-30	32.09000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-29	32.05000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-28	32.01000000	2026-09-02 03:19:25.987378+00
ICL	2026-04-27	31.96000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-17	28.54000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-16	28.53000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-15	28.51000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-14	28.50000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-13	28.48000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-12	28.47000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-11	28.45000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-10	28.44000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-09	28.42000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-08	28.41000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-07	28.40000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-06	28.38000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-05	28.37000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-04	28.35000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-03	28.34000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-02	28.32000000	2026-09-02 03:19:25.987378+00
ICL	2025-11-01	28.31000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-31	28.29000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-30	28.28000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-29	28.27000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-28	28.25000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-27	28.24000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-26	28.22000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-25	28.21000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-24	28.19000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-23	28.18000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-22	28.17000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-21	28.15000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-20	28.14000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-19	28.12000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-18	28.11000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-17	28.09000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-16	28.08000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-15	28.06000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-14	28.04000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-13	28.01000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-12	27.99000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-11	27.97000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-10	27.95000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-09	27.92000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-08	27.90000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-07	27.88000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-06	27.86000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-05	27.84000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-04	27.81000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-03	27.79000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-02	27.77000000	2026-09-02 03:19:25.987378+00
ICL	2025-10-01	27.75000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-30	27.73000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-29	27.70000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-28	27.68000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-27	27.66000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-26	27.64000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-25	27.62000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-24	27.60000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-23	27.57000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-22	27.55000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-21	27.53000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-20	27.51000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-19	27.49000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-18	27.47000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-17	27.44000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-16	27.42000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-15	27.40000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-14	27.38000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-13	27.36000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-12	27.35000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-11	27.33000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-10	27.31000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-09	27.29000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-08	27.27000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-07	27.25000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-06	27.23000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-05	27.21000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-04	27.19000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-03	27.17000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-02	27.15000000	2026-09-02 03:19:25.987378+00
ICL	2025-09-01	27.14000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-31	27.12000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-30	27.10000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-29	27.08000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-28	27.06000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-27	27.04000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-26	27.02000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-25	27.00000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-24	26.98000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-23	26.97000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-22	26.95000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-21	26.93000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-20	26.91000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-19	26.89000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-18	26.87000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-17	26.85000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-16	26.83000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-15	26.82000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-14	26.80000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-13	26.79000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-12	26.78000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-11	26.76000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-10	26.75000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-09	26.73000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-08	26.72000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-07	26.70000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-06	26.69000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-05	26.68000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-04	26.66000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-03	26.65000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-02	26.63000000	2026-09-02 03:19:25.987378+00
ICL	2025-08-01	26.62000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-31	26.60000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-30	26.59000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-29	26.58000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-28	26.56000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-27	26.55000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-26	26.53000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-25	26.52000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-24	26.50000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-23	26.49000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-22	26.48000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-21	26.46000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-20	26.45000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-19	26.43000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-18	26.42000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-17	26.40000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-16	26.39000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-15	26.37000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-14	26.34000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-13	26.32000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-12	26.29000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-11	26.27000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-10	26.24000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-09	26.22000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-08	26.20000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-07	26.17000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-06	26.15000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-05	26.12000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-04	26.10000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-03	26.07000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-02	26.05000000	2026-09-02 03:19:25.987378+00
ICL	2025-07-01	26.03000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-30	26.00000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-29	25.98000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-28	25.95000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-27	25.93000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-26	25.91000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-25	25.88000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-24	25.86000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-23	25.83000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-22	25.81000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-21	25.79000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-20	25.76000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-19	25.74000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-18	25.71000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-17	25.69000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-16	25.67000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-15	25.63000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-14	25.60000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-13	25.57000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-12	25.54000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-11	25.51000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-10	25.48000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-09	25.45000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-08	25.41000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-07	25.38000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-06	25.35000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-05	25.32000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-04	25.29000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-03	25.26000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-02	25.23000000	2026-09-02 03:19:25.987378+00
ICL	2025-06-01	25.20000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-31	25.16000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-30	25.13000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-29	25.10000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-28	25.07000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-27	25.04000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-26	25.01000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-25	24.98000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-24	24.95000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-23	24.92000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-22	24.89000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-21	24.86000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-20	24.83000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-19	24.80000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-18	24.77000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-17	24.73000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-16	24.70000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-15	24.67000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-14	24.64000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-13	24.60000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-12	24.57000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-11	24.53000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-10	24.50000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-09	24.46000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-08	24.43000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-07	24.40000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-06	24.36000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-05	24.33000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-04	24.29000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-03	24.26000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-02	24.23000000	2026-09-02 03:19:25.987378+00
ICL	2025-05-01	24.19000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-30	24.16000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-29	24.13000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-28	24.09000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-27	24.06000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-26	24.03000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-25	23.99000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-24	23.96000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-23	23.93000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-22	23.89000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-21	23.86000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-20	23.83000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-19	23.79000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-18	23.76000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-17	23.73000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-16	23.69000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-15	23.67000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-14	23.66000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-13	23.64000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-12	23.62000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-11	23.60000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-10	23.58000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-09	23.57000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-08	23.55000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-07	23.53000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-06	23.51000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-05	23.49000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-04	23.47000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-03	23.46000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-02	23.44000000	2026-09-02 03:19:25.987378+00
ICL	2025-04-01	23.42000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-31	23.40000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-30	23.38000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-29	23.37000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-28	23.35000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-27	23.33000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-26	23.31000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-25	23.29000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-24	23.28000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-23	23.26000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-22	23.24000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-21	23.22000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-20	23.20000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-19	23.19000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-18	23.17000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-17	23.15000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-16	23.13000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-15	23.11000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-14	23.09000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-13	23.07000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-12	23.06000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-11	23.04000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-10	23.02000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-09	23.00000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-08	22.98000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-07	22.96000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-06	22.94000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-05	22.92000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-04	22.90000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-03	22.88000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-02	22.86000000	2026-09-02 03:19:25.987378+00
ICL	2025-03-01	22.84000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-28	22.82000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-27	22.81000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-26	22.79000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-25	22.77000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-24	22.75000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-23	22.73000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-22	22.71000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-21	22.69000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-20	22.67000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-19	22.65000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-18	22.63000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-17	22.62000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-16	22.60000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-15	22.58000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-14	22.56000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-13	22.54000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-12	22.52000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-11	22.50000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-10	22.48000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-09	22.46000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-08	22.45000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-07	22.43000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-06	22.41000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-05	22.39000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-04	22.37000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-03	22.35000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-02	22.33000000	2026-09-02 03:19:25.987378+00
ICL	2025-02-01	22.31000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-31	22.30000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-30	22.28000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-29	22.26000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-28	22.24000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-27	22.22000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-26	22.20000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-25	22.18000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-24	22.17000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-23	22.15000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-22	22.13000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-21	22.11000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-20	22.09000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-19	22.07000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-18	22.05000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-17	22.04000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-16	22.02000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-15	21.99000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-14	21.95000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-13	21.92000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-12	21.89000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-11	21.86000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-10	21.82000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-09	21.79000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-08	21.76000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-07	21.73000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-06	21.70000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-05	21.66000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-04	21.63000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-03	21.60000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-02	21.57000000	2026-09-02 03:19:25.987378+00
ICL	2025-01-01	21.54000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-31	21.51000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-30	21.47000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-29	21.44000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-28	21.41000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-27	21.38000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-26	21.35000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-25	21.32000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-24	21.29000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-23	21.25000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-22	21.22000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-21	21.19000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-20	21.16000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-19	21.13000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-18	21.10000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-17	21.07000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-16	21.04000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-15	21.01000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-14	20.98000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-13	20.96000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-12	20.93000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-11	20.91000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-10	20.88000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-09	20.85000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-08	20.83000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-07	20.80000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-06	20.78000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-05	20.75000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-04	20.73000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-03	20.70000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-02	20.67000000	2026-09-02 03:19:25.987378+00
ICL	2024-12-01	20.65000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-30	20.62000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-29	20.60000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-28	20.57000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-27	20.55000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-26	20.52000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-25	20.49000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-24	20.47000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-23	20.44000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-22	20.42000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-21	20.39000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-20	20.37000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-19	20.34000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-18	20.32000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-17	20.29000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-16	20.27000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-15	20.24000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-14	20.22000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-13	20.19000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-12	20.16000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-11	20.14000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-10	20.11000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-09	20.09000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-08	20.06000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-07	20.04000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-06	20.01000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-05	19.99000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-04	19.96000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-03	19.94000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-02	19.91000000	2026-09-02 03:19:25.987378+00
ICL	2024-11-01	19.89000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-31	19.86000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-30	19.84000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-29	19.81000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-28	19.79000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-27	19.76000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-26	19.74000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-25	19.71000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-24	19.69000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-23	19.66000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-22	19.64000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-21	19.61000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-20	19.59000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-19	19.56000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-18	19.54000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-17	19.51000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-16	19.49000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-15	19.46000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-14	19.42000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-13	19.39000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-12	19.36000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-11	19.32000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-10	19.29000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-09	19.26000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-08	19.22000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-07	19.19000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-06	19.16000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-05	19.12000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-04	19.09000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-03	19.06000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-02	19.02000000	2026-09-02 03:19:25.987378+00
ICL	2024-10-01	18.99000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-30	18.96000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-29	18.93000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-28	18.89000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-27	18.86000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-26	18.83000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-25	18.80000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-24	18.76000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-23	18.73000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-22	18.70000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-21	18.67000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-20	18.64000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-19	18.60000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-18	18.57000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-17	18.54000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-16	18.51000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-15	18.48000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-14	18.45000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-13	18.41000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-12	18.38000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-11	18.35000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-10	18.32000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-09	18.29000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-08	18.26000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-07	18.23000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-06	18.20000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-05	18.17000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-04	18.14000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-03	18.11000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-02	18.08000000	2026-09-02 03:19:25.987378+00
ICL	2024-09-01	18.05000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-31	18.02000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-30	17.99000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-29	17.96000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-28	17.93000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-27	17.90000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-26	17.87000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-25	17.84000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-24	17.81000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-23	17.78000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-22	17.75000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-21	17.72000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-20	17.69000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-19	17.66000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-18	17.63000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-17	17.60000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-16	17.57000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-15	17.54000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-14	17.51000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-13	17.47000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-12	17.44000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-11	17.41000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-10	17.38000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-09	17.35000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-08	17.32000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-07	17.29000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-06	17.25000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-05	17.22000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-04	17.19000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-03	17.16000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-02	17.13000000	2026-09-02 03:19:25.987378+00
ICL	2024-08-01	17.10000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-31	17.07000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-30	17.04000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-29	17.01000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-28	16.98000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-27	16.95000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-26	16.92000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-25	16.89000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-24	16.86000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-23	16.82000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-22	16.79000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-21	16.76000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-20	16.73000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-19	16.70000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-18	16.67000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-17	16.64000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-16	16.61000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-15	16.55000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-14	16.48000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-13	16.42000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-12	16.36000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-11	16.29000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-10	16.23000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-09	16.16000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-08	16.10000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-07	16.04000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-06	15.98000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-05	15.91000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-04	15.85000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-03	15.79000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-02	15.73000000	2026-09-02 03:19:25.987378+00
ICL	2024-07-01	15.67000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-30	15.60000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-29	15.54000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-28	15.48000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-27	15.42000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-26	15.36000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-25	15.30000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-24	15.24000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-23	15.18000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-22	15.12000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-21	15.06000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-20	15.01000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-19	14.95000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-18	14.89000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-17	14.83000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-16	14.77000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-15	14.72000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-14	14.66000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-13	14.60000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-12	14.55000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-11	14.49000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-10	14.44000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-09	14.38000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-08	14.33000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-07	14.27000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-06	14.22000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-05	14.17000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-04	14.11000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-03	14.06000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-02	14.01000000	2026-09-02 03:19:25.987378+00
ICL	2024-06-01	13.95000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-31	13.90000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-30	13.85000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-29	13.79000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-28	13.74000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-27	13.69000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-26	13.64000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-25	13.59000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-24	13.53000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-23	13.48000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-22	13.43000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-21	13.38000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-20	13.33000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-19	13.28000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-18	13.23000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-17	13.18000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-16	13.13000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-15	13.08000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-14	13.03000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-13	12.98000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-12	12.93000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-11	12.88000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-10	12.83000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-09	12.78000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-08	12.73000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-07	12.68000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-06	12.63000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-05	12.58000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-04	12.53000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-03	12.48000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-02	12.43000000	2026-09-02 03:19:25.987378+00
ICL	2024-05-01	12.39000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-30	12.34000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-29	12.29000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-28	12.24000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-27	12.19000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-26	12.15000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-25	12.10000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-24	12.05000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-23	12.01000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-22	11.96000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-21	11.91000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-20	11.87000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-19	11.82000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-18	11.78000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-17	11.73000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-16	11.68000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-15	11.62000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-14	11.56000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-13	11.50000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-12	11.44000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-11	11.38000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-10	11.32000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-09	11.26000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-08	11.20000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-07	11.15000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-06	11.09000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-05	11.03000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-04	10.97000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-03	10.92000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-02	10.86000000	2026-09-02 03:19:25.987378+00
ICL	2024-04-01	10.80000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-31	10.74000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-30	10.69000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-29	10.63000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-28	10.58000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-27	10.52000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-26	10.47000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-25	10.41000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-24	10.36000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-23	10.30000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-22	10.25000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-21	10.20000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-20	10.14000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-19	10.09000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-18	10.04000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-17	9.98000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-16	9.93000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-15	9.88000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-14	9.83000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-13	9.77000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-12	9.72000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-11	9.67000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-10	9.62000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-09	9.57000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-08	9.51000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-07	9.46000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-06	9.41000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-05	9.36000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-04	9.31000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-03	9.26000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-02	9.21000000	2026-09-02 03:19:25.987378+00
ICL	2024-03-01	9.16000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-29	9.11000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-28	9.06000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-27	9.02000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-26	8.97000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-25	8.92000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-24	8.87000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-23	8.82000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-22	8.78000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-21	8.73000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-20	8.68000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-19	8.64000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-18	8.59000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-17	8.54000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-16	8.50000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-15	8.47000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-14	8.45000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-13	8.42000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-12	8.40000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-11	8.37000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-10	8.35000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-09	8.32000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-08	8.30000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-07	8.28000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-06	8.25000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-05	8.23000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-04	8.20000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-03	8.18000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-02	8.15000000	2026-09-02 03:19:25.987378+00
ICL	2024-02-01	8.13000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-31	8.11000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-30	8.08000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-29	8.06000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-28	8.04000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-27	8.01000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-26	7.99000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-25	7.97000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-24	7.94000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-23	7.92000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-22	7.90000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-21	7.87000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-20	7.85000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-19	7.83000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-18	7.80000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-17	7.78000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-16	7.76000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-15	7.73000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-14	7.71000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-13	7.69000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-12	7.66000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-11	7.64000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-10	7.62000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-09	7.59000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-08	7.57000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-07	7.55000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-06	7.52000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-05	7.50000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-04	7.48000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-03	7.45000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-02	7.43000000	2026-09-02 03:19:25.987378+00
ICL	2024-01-01	7.41000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-31	7.38000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-30	7.36000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-29	7.34000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-28	7.32000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-27	7.29000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-26	7.27000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-25	7.25000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-24	7.23000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-23	7.20000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-22	7.18000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-21	7.16000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-20	7.14000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-19	7.12000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-18	7.09000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-17	7.07000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-16	7.05000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-15	7.03000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-14	7.00000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-13	6.98000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-12	6.95000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-11	6.93000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-10	6.90000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-09	6.88000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-08	6.86000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-07	6.83000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-06	6.81000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-05	6.78000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-04	6.76000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-03	6.74000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-02	6.71000000	2026-09-02 03:19:25.987378+00
ICL	2023-12-01	6.69000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-30	6.67000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-29	6.64000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-28	6.62000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-27	6.60000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-26	6.57000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-25	6.55000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-24	6.53000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-23	6.50000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-22	6.48000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-21	6.46000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-20	6.44000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-19	6.41000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-18	6.39000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-17	6.37000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-16	6.35000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-15	6.33000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-14	6.31000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-13	6.29000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-12	6.28000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-11	6.26000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-10	6.24000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-09	6.22000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-08	6.20000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-07	6.19000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-06	6.17000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-05	6.15000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-04	6.14000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-03	6.12000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-02	6.10000000	2026-09-02 03:19:25.987378+00
ICL	2023-11-01	6.08000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-31	6.07000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-30	6.05000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-29	6.03000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-28	6.02000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-27	6.00000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-26	5.98000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-25	5.96000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-24	5.95000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-23	5.93000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-22	5.91000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-21	5.90000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-20	5.88000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-19	5.86000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-18	5.85000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-17	5.83000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-16	5.81000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-15	5.80000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-14	5.79000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-13	5.78000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-12	5.76000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-11	5.75000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-10	5.74000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-09	5.72000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-08	5.71000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-07	5.70000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-06	5.69000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-05	5.67000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-04	5.66000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-03	5.65000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-02	5.64000000	2026-09-02 03:19:25.987378+00
ICL	2023-10-01	5.62000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-30	5.61000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-29	5.60000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-28	5.59000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-27	5.57000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-26	5.56000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-25	5.55000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-24	5.54000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-23	5.53000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-22	5.51000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-21	5.50000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-20	5.49000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-19	5.48000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-18	5.46000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-17	5.45000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-16	5.44000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-15	5.43000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-14	5.42000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-13	5.40000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-12	5.39000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-11	5.38000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-10	5.37000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-09	5.36000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-08	5.35000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-07	5.33000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-06	5.32000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-05	5.31000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-04	5.30000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-03	5.29000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-02	5.28000000	2026-09-02 03:19:25.987378+00
ICL	2023-09-01	5.26000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-31	5.25000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-30	5.24000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-29	5.23000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-28	5.22000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-27	5.21000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-26	5.20000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-25	5.18000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-24	5.17000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-23	5.16000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-22	5.15000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-21	5.14000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-20	5.13000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-19	5.12000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-18	5.10000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-17	5.09000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-16	5.08000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-15	5.07000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-14	5.06000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-13	5.05000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-12	5.04000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-11	5.03000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-10	5.02000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-09	5.01000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-08	4.99000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-07	4.98000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-06	4.97000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-05	4.96000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-04	4.95000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-03	4.94000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-02	4.93000000	2026-09-02 03:19:25.987378+00
ICL	2023-08-01	4.92000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-31	4.91000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-30	4.90000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-29	4.89000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-28	4.88000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-27	4.87000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-26	4.86000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-25	4.84000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-24	4.83000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-23	4.82000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-22	4.81000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-21	4.80000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-20	4.79000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-19	4.78000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-18	4.77000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-17	4.76000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-16	4.75000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-15	4.74000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-14	4.72000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-13	4.71000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-12	4.70000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-11	4.68000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-10	4.67000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-09	4.65000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-08	4.64000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-07	4.63000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-06	4.61000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-05	4.60000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-04	4.59000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-03	4.57000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-02	4.56000000	2026-09-02 03:19:25.987378+00
ICL	2023-07-01	4.55000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-30	4.53000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-29	4.52000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-28	4.51000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-27	4.50000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-26	4.48000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-25	4.47000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-24	4.46000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-23	4.44000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-22	4.43000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-21	4.42000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-20	4.40000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-19	4.39000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-18	4.38000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-17	4.37000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-16	4.35000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-15	4.34000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-14	4.33000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-13	4.32000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-12	4.31000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-11	4.30000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-10	4.28000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-09	4.27000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-08	4.26000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-07	4.25000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-06	4.24000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-05	4.23000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-04	4.21000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-03	4.20000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-02	4.19000000	2026-09-02 03:19:25.987378+00
ICL	2023-06-01	4.18000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-31	4.17000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-30	4.16000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-29	4.15000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-28	4.14000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-27	4.12000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-26	4.11000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-25	4.10000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-24	4.09000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-23	4.08000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-22	4.07000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-21	4.06000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-20	4.05000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-19	4.04000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-18	4.03000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-17	4.02000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-16	4.00000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-15	3.99000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-14	3.99000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-13	3.98000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-12	3.97000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-11	3.96000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-10	3.95000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-09	3.94000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-08	3.93000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-07	3.92000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-06	3.91000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-05	3.90000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-04	3.89000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-03	3.88000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-02	3.87000000	2026-09-02 03:19:25.987378+00
ICL	2023-05-01	3.86000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-30	3.85000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-29	3.84000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-28	3.83000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-27	3.82000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-26	3.82000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-25	3.81000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-24	3.80000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-23	3.79000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-22	3.78000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-21	3.77000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-20	3.76000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-19	3.75000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-18	3.74000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-17	3.73000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-16	3.72000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-15	3.72000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-14	3.71000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-13	3.71000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-12	3.70000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-11	3.70000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-10	3.69000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-09	3.68000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-08	3.68000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-07	3.67000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-06	3.67000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-05	3.66000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-04	3.66000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-03	3.65000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-02	3.64000000	2026-09-02 03:19:25.987378+00
ICL	2023-04-01	3.64000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-31	3.63000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-30	3.63000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-29	3.62000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-28	3.62000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-27	3.61000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-26	3.61000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-25	3.60000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-24	3.59000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-23	3.59000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-22	3.58000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-21	3.58000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-20	3.57000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-19	3.57000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-18	3.56000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-17	3.56000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-16	3.55000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-15	3.54000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-14	3.54000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-13	3.53000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-12	3.52000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-11	3.52000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-10	3.51000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-09	3.50000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-08	3.50000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-07	3.49000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-06	3.49000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-05	3.48000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-04	3.47000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-03	3.47000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-02	3.46000000	2026-09-02 03:19:25.987378+00
ICL	2023-03-01	3.45000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-28	3.45000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-27	3.44000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-26	3.43000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-25	3.43000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-24	3.42000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-23	3.42000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-22	3.41000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-21	3.40000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-20	3.40000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-19	3.39000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-18	3.38000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-17	3.38000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-16	3.37000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-15	3.37000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-14	3.36000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-13	3.36000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-12	3.35000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-11	3.34000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-10	3.34000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-09	3.33000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-08	3.33000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-07	3.32000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-06	3.32000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-05	3.31000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-04	3.31000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-03	3.30000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-02	3.29000000	2026-09-02 03:19:25.987378+00
ICL	2023-02-01	3.29000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-31	3.28000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-30	3.28000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-29	3.27000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-28	3.27000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-27	3.26000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-26	3.26000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-25	3.25000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-24	3.25000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-23	3.24000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-22	3.24000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-21	3.23000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-20	3.22000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-19	3.22000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-18	3.21000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-17	3.21000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-16	3.20000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-15	3.20000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-14	3.19000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-13	3.19000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-12	3.18000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-11	3.17000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-10	3.17000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-09	3.16000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-08	3.16000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-07	3.15000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-06	3.14000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-05	3.14000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-04	3.13000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-03	3.13000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-02	3.12000000	2026-09-02 03:19:25.987378+00
ICL	2023-01-01	3.12000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-31	3.11000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-30	3.10000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-29	3.10000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-28	3.09000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-27	3.09000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-26	3.08000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-25	3.08000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-24	3.07000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-23	3.06000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-22	3.06000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-21	3.05000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-20	3.05000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-19	3.04000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-18	3.04000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-17	3.03000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-16	3.03000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-15	3.02000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-14	3.01000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-13	3.01000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-12	3.00000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-11	2.99000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-10	2.99000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-09	2.98000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-08	2.98000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-07	2.97000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-06	2.96000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-05	2.96000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-04	2.95000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-03	2.95000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-02	2.94000000	2026-09-02 03:19:25.987378+00
ICL	2022-12-01	2.93000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-30	2.93000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-29	2.92000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-28	2.92000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-27	2.91000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-26	2.91000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-25	2.90000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-24	2.89000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-23	2.89000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-22	2.88000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-21	2.88000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-20	2.87000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-19	2.86000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-18	2.86000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-17	2.85000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-16	2.85000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-15	2.84000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-14	2.84000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-13	2.83000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-12	2.83000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-11	2.82000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-10	2.82000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-09	2.81000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-08	2.81000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-07	2.80000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-06	2.80000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-05	2.79000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-04	2.79000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-03	2.78000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-02	2.78000000	2026-09-02 03:19:25.987378+00
ICL	2022-11-01	2.77000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-31	2.77000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-30	2.76000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-29	2.76000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-28	2.75000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-27	2.75000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-26	2.74000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-25	2.74000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-24	2.73000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-23	2.73000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-22	2.72000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-21	2.72000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-20	2.71000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-19	2.71000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-18	2.70000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-17	2.70000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-16	2.69000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-15	2.69000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-14	2.68000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-13	2.68000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-12	2.67000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-11	2.66000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-10	2.66000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-09	2.65000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-08	2.65000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-07	2.64000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-06	2.64000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-05	2.63000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-04	2.63000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-03	2.62000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-02	2.62000000	2026-09-02 03:19:25.987378+00
ICL	2022-10-01	2.61000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-30	2.61000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-29	2.60000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-28	2.59000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-27	2.59000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-26	2.58000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-25	2.58000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-24	2.57000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-23	2.57000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-22	2.56000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-21	2.56000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-20	2.55000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-19	2.55000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-18	2.54000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-17	2.54000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-16	2.53000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-15	2.53000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-14	2.52000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-13	2.52000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-12	2.51000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-11	2.51000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-10	2.50000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-09	2.50000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-08	2.50000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-07	2.49000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-06	2.49000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-05	2.48000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-04	2.48000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-03	2.47000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-02	2.47000000	2026-09-02 03:19:25.987378+00
ICL	2022-09-01	2.47000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-31	2.46000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-30	2.46000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-29	2.45000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-28	2.45000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-27	2.44000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-26	2.44000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-25	2.44000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-24	2.43000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-23	2.43000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-22	2.42000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-21	2.42000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-20	2.42000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-19	2.41000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-18	2.41000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-17	2.40000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-16	2.40000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-15	2.40000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-14	2.39000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-13	2.39000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-12	2.38000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-11	2.38000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-10	2.38000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-09	2.37000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-08	2.37000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-07	2.37000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-06	2.36000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-05	2.36000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-04	2.36000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-03	2.35000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-02	2.35000000	2026-09-02 03:19:25.987378+00
ICL	2022-08-01	2.35000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-31	2.34000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-30	2.34000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-29	2.34000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-28	2.33000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-27	2.33000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-26	2.33000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-25	2.32000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-24	2.32000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-23	2.32000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-22	2.31000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-21	2.31000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-20	2.31000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-19	2.30000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-18	2.30000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-17	2.30000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-16	2.29000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-15	2.29000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-14	2.29000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-13	2.28000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-12	2.28000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-11	2.27000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-10	2.27000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-09	2.26000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-08	2.26000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-07	2.25000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-06	2.25000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-05	2.25000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-04	2.24000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-03	2.24000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-02	2.23000000	2026-09-02 03:19:25.987378+00
ICL	2022-07-01	2.23000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-30	2.22000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-29	2.22000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-28	2.22000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-27	2.21000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-26	2.21000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-25	2.20000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-24	2.20000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-23	2.19000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-22	2.19000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-21	2.19000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-20	2.18000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-19	2.18000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-18	2.17000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-17	2.17000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-16	2.16000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-15	2.16000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-14	2.15000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-13	2.15000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-12	2.15000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-11	2.14000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-10	2.14000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-09	2.13000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-08	2.13000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-07	2.12000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-06	2.12000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-05	2.11000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-04	2.11000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-03	2.10000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-02	2.10000000	2026-09-02 03:19:25.987378+00
ICL	2022-06-01	2.09000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-31	2.09000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-30	2.08000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-29	2.08000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-28	2.07000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-27	2.07000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-26	2.06000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-25	2.06000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-24	2.05000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-23	2.05000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-22	2.05000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-21	2.04000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-20	2.04000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-19	2.03000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-18	2.03000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-17	2.02000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-16	2.02000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-15	2.01000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-14	2.01000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-13	2.01000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-12	2.01000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-11	2.00000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-10	2.00000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-09	2.00000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-08	1.99000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-07	1.99000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-06	1.99000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-05	1.98000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-04	1.98000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-03	1.98000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-02	1.97000000	2026-09-02 03:19:25.987378+00
ICL	2022-05-01	1.97000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-30	1.97000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-29	1.97000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-28	1.96000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-27	1.96000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-26	1.96000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-25	1.95000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-24	1.95000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-23	1.95000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-22	1.94000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-21	1.94000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-20	1.94000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-19	1.94000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-18	1.93000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-17	1.93000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-16	1.93000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-15	1.92000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-14	1.92000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-13	1.92000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-12	1.92000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-11	1.91000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-10	1.91000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-09	1.91000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-08	1.91000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-07	1.90000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-06	1.90000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-05	1.90000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-04	1.90000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-03	1.89000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-02	1.89000000	2026-09-02 03:19:25.987378+00
ICL	2022-04-01	1.89000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-31	1.89000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-30	1.88000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-29	1.88000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-28	1.88000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-27	1.88000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-26	1.87000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-25	1.87000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-24	1.87000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-23	1.87000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-22	1.86000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-21	1.86000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-20	1.86000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-19	1.86000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-18	1.85000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-17	1.85000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-16	1.85000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-15	1.85000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-14	1.84000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-13	1.84000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-12	1.84000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-11	1.84000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-10	1.84000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-09	1.84000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-08	1.83000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-07	1.83000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-06	1.83000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-05	1.83000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-04	1.83000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-03	1.82000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-02	1.82000000	2026-09-02 03:19:25.987378+00
ICL	2022-03-01	1.82000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-28	1.82000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-27	1.82000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-26	1.81000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-25	1.81000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-24	1.81000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-23	1.81000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-22	1.81000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-21	1.81000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-20	1.80000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-19	1.80000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-18	1.80000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-17	1.80000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-16	1.80000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-15	1.79000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-14	1.79000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-13	1.79000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-12	1.79000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-11	1.79000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-10	1.79000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-09	1.78000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-08	1.78000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-07	1.78000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-06	1.78000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-05	1.78000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-04	1.78000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-03	1.78000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-02	1.77000000	2026-09-02 03:19:25.987378+00
ICL	2022-02-01	1.77000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-31	1.77000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-30	1.77000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-29	1.77000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-28	1.77000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-27	1.76000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-26	1.76000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-25	1.76000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-24	1.76000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-23	1.76000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-22	1.76000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-21	1.75000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-20	1.75000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-19	1.75000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-18	1.75000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-17	1.75000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-16	1.75000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-15	1.74000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-14	1.74000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-13	1.74000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-12	1.74000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-11	1.74000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-10	1.73000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-09	1.73000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-08	1.73000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-07	1.73000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-06	1.73000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-05	1.73000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-04	1.72000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-03	1.72000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-02	1.72000000	2026-09-02 03:19:25.987378+00
ICL	2022-01-01	1.72000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-31	1.72000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-30	1.71000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-29	1.71000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-28	1.71000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-27	1.71000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-26	1.71000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-25	1.70000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-24	1.70000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-23	1.70000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-22	1.70000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-21	1.70000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-20	1.69000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-19	1.69000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-18	1.69000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-17	1.69000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-16	1.69000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-15	1.68000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-14	1.68000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-13	1.68000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-12	1.68000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-11	1.68000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-10	1.67000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-09	1.67000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-08	1.67000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-07	1.67000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-06	1.67000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-05	1.66000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-04	1.66000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-03	1.66000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-02	1.66000000	2026-09-02 03:19:25.987378+00
ICL	2021-12-01	1.65000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-30	1.65000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-29	1.65000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-28	1.65000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-27	1.65000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-26	1.64000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-25	1.64000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-24	1.64000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-23	1.64000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-22	1.64000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-21	1.63000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-20	1.63000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-19	1.63000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-18	1.63000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-17	1.63000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-16	1.62000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-15	1.62000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-14	1.62000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-13	1.62000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-12	1.62000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-11	1.62000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-10	1.62000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-09	1.61000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-08	1.61000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-07	1.61000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-06	1.61000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-05	1.61000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-04	1.61000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-03	1.61000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-02	1.61000000	2026-09-02 03:19:25.987378+00
ICL	2021-11-01	1.60000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-31	1.60000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-30	1.60000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-29	1.60000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-28	1.60000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-27	1.60000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-26	1.60000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-25	1.60000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-24	1.60000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-23	1.59000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-22	1.59000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-21	1.59000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-20	1.59000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-19	1.59000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-18	1.59000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-17	1.59000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-16	1.59000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-15	1.58000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-14	1.58000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-13	1.58000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-12	1.58000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-11	1.58000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-10	1.57000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-09	1.57000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-08	1.57000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-07	1.57000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-06	1.57000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-05	1.56000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-04	1.56000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-03	1.56000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-02	1.56000000	2026-09-02 03:19:25.987378+00
ICL	2021-10-01	1.56000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-30	1.55000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-29	1.55000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-28	1.55000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-27	1.55000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-26	1.55000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-25	1.55000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-24	1.54000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-23	1.54000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-22	1.54000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-21	1.54000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-20	1.54000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-19	1.53000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-18	1.53000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-17	1.53000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-16	1.53000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-15	1.53000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-14	1.53000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-13	1.52000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-12	1.52000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-11	1.52000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-10	1.52000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-09	1.52000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-08	1.52000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-07	1.51000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-06	1.51000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-05	1.51000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-04	1.51000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-03	1.51000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-02	1.51000000	2026-09-02 03:19:25.987378+00
ICL	2021-09-01	1.50000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-31	1.50000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-30	1.50000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-29	1.50000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-28	1.50000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-27	1.50000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-26	1.49000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-25	1.49000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-24	1.49000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-23	1.49000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-22	1.49000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-21	1.49000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-20	1.48000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-19	1.48000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-18	1.48000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-17	1.48000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-16	1.48000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-15	1.48000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-14	1.48000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-13	1.47000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-12	1.47000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-11	1.47000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-10	1.47000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-09	1.47000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-08	1.47000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-07	1.47000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-06	1.47000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-05	1.47000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-04	1.46000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-03	1.46000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-02	1.46000000	2026-09-02 03:19:25.987378+00
ICL	2021-08-01	1.46000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-31	1.46000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-30	1.46000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-29	1.46000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-28	1.46000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-27	1.46000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-26	1.46000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-25	1.45000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-24	1.45000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-23	1.45000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-22	1.45000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-21	1.45000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-20	1.45000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-19	1.45000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-18	1.45000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-17	1.45000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-16	1.44000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-15	1.44000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-14	1.44000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-13	1.44000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-12	1.44000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-11	1.43000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-10	1.43000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-09	1.43000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-08	1.43000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-07	1.42000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-06	1.42000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-05	1.42000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-04	1.42000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-03	1.41000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-02	1.41000000	2026-09-02 03:19:25.987378+00
ICL	2021-07-01	1.41000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-30	1.41000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-29	1.40000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-28	1.40000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-27	1.40000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-26	1.40000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-25	1.39000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-24	1.39000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-23	1.39000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-22	1.39000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-21	1.39000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-20	1.38000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-19	1.38000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-18	1.38000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-17	1.38000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-16	1.37000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-15	1.37000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-14	1.37000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-13	1.37000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-12	1.37000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-11	1.36000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-10	1.36000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-09	1.36000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-08	1.36000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-07	1.36000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-06	1.35000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-05	1.35000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-04	1.35000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-03	1.35000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-02	1.35000000	2026-09-02 03:19:25.987378+00
ICL	2021-06-01	1.34000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-31	1.34000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-30	1.34000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-29	1.34000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-28	1.33000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-27	1.33000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-26	1.33000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-25	1.33000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-24	1.33000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-23	1.32000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-22	1.32000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-21	1.32000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-20	1.32000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-19	1.32000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-18	1.31000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-17	1.31000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-16	1.31000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-15	1.31000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-14	1.31000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-13	1.30000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-12	1.30000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-11	1.30000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-10	1.30000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-09	1.30000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-08	1.29000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-07	1.29000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-06	1.29000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-05	1.29000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-04	1.29000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-03	1.28000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-02	1.28000000	2026-09-02 03:19:25.987378+00
ICL	2021-05-01	1.28000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-30	1.28000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-29	1.28000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-28	1.27000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-27	1.27000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-26	1.27000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-25	1.27000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-24	1.27000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-23	1.26000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-22	1.26000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-21	1.26000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-20	1.26000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-19	1.26000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-18	1.25000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-17	1.25000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-16	1.25000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-15	1.25000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-14	1.25000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-13	1.25000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-12	1.25000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-11	1.24000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-10	1.24000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-09	1.24000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-08	1.24000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-07	1.24000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-06	1.24000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-05	1.24000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-04	1.24000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-03	1.23000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-02	1.23000000	2026-09-02 03:19:25.987378+00
ICL	2021-04-01	1.23000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-31	1.23000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-30	1.23000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-29	1.23000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-28	1.23000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-27	1.23000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-26	1.23000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-25	1.22000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-24	1.22000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-23	1.22000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-22	1.22000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-21	1.22000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-20	1.22000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-19	1.22000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-18	1.22000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-17	1.22000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-16	1.21000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-15	1.21000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-14	1.21000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-13	1.21000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-12	1.21000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-11	1.21000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-10	1.21000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-09	1.21000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-08	1.20000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-07	1.20000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-06	1.20000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-05	1.20000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-04	1.20000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-03	1.20000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-02	1.20000000	2026-09-02 03:19:25.987378+00
ICL	2021-03-01	1.20000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-28	1.19000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-27	1.19000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-26	1.19000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-25	1.19000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-10	1.17000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-09	1.17000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-08	1.17000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-07	1.17000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-06	1.17000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-05	1.17000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-04	1.17000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-03	1.17000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-02	1.17000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-01	1.17000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-31	1.17000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-30	1.16000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-29	1.16000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-24	1.19000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-23	1.19000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-22	1.19000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-21	1.19000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-20	1.18000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-19	1.18000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-18	1.18000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-17	1.18000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-16	1.18000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-15	1.18000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-14	1.18000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-13	1.18000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-12	1.18000000	2026-09-02 03:19:25.987378+00
ICL	2021-02-11	1.17000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-28	1.16000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-27	1.16000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-26	1.16000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-25	1.16000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-24	1.16000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-23	1.16000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-22	1.16000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-21	1.16000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-20	1.16000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-19	1.16000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-18	1.16000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-17	1.15000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-16	1.15000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-15	1.15000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-14	1.15000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-13	1.15000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-12	1.15000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-11	1.15000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-10	1.14000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-09	1.14000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-08	1.14000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-07	1.14000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-06	1.14000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-05	1.14000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-04	1.14000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-03	1.13000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-02	1.13000000	2026-09-02 03:19:25.987378+00
ICL	2021-01-01	1.13000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-31	1.13000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-30	1.13000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-29	1.13000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-28	1.12000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-27	1.12000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-26	1.12000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-25	1.12000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-24	1.12000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-23	1.12000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-22	1.12000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-21	1.11000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-20	1.11000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-19	1.11000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-18	1.11000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-17	1.11000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-16	1.11000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-15	1.11000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-14	1.11000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-13	1.10000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-12	1.10000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-11	1.10000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-10	1.10000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-09	1.10000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-08	1.10000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-07	1.10000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-06	1.10000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-05	1.10000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-04	1.10000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-03	1.10000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-02	1.10000000	2026-09-02 03:19:25.987378+00
ICL	2020-12-01	1.09000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-30	1.09000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-29	1.09000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-28	1.09000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-27	1.09000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-26	1.09000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-25	1.09000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-24	1.09000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-21	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-20	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-19	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-18	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-17	1.06000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-16	1.06000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-15	1.06000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-14	1.06000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-13	1.06000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-12	1.06000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-11	1.06000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-10	1.06000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-09	1.06000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-08	1.06000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-07	1.06000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-06	1.05000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-05	1.05000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-04	1.05000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-03	1.05000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-02	1.05000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-01	1.05000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-30	1.05000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-29	1.05000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-28	1.05000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-27	1.05000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-26	1.05000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-25	1.04000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-24	1.04000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-07	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-06	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-05	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-04	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-03	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-02	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-01	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-31	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-30	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-29	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-28	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-27	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-26	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-25	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-24	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-23	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-22	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-21	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-20	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-19	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-18	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-17	1.00000000	2026-09-02 03:19:25.987378+00
IPC	2026-08-01	12276.76600000	2026-09-12 12:28:23.282408+00
ICL	2020-11-23	1.09000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-22	1.09000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-21	1.09000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-20	1.09000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-19	1.08000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-18	1.08000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-17	1.08000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-16	1.08000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-15	1.08000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-14	1.08000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-13	1.08000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-12	1.08000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-11	1.08000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-10	1.08000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-09	1.08000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-08	1.08000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-07	1.08000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-06	1.08000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-05	1.08000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-04	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-03	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-02	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-11-01	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-31	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-30	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-29	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-28	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-27	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-26	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-25	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-24	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-23	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-10-22	1.07000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-23	1.04000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-22	1.04000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-21	1.04000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-20	1.04000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-19	1.04000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-18	1.04000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-17	1.04000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-16	1.04000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-15	1.04000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-14	1.03000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-13	1.03000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-12	1.03000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-11	1.03000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-10	1.03000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-09	1.03000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-08	1.03000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-07	1.03000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-06	1.03000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-05	1.03000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-13	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-12	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-11	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-10	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-09	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-08	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-16	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-15	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-14	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-13	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-12	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-11	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-10	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-09	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-08	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-07	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-06	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-05	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-04	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-03	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-02	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-07-01	1.00000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-04	1.03000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-03	1.03000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-02	1.03000000	2026-09-02 03:19:25.987378+00
ICL	2020-09-01	1.02000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-31	1.02000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-30	1.02000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-29	1.02000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-28	1.02000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-27	1.02000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-26	1.02000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-25	1.02000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-24	1.02000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-23	1.02000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-22	1.02000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-21	1.02000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-20	1.02000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-19	1.02000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-18	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-17	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-16	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-15	1.01000000	2026-09-02 03:19:25.987378+00
ICL	2020-08-14	1.01000000	2026-09-02 03:19:25.987378+00
IPC	2023-07-01	1818.08380000	2026-08-31 22:02:54.272143+00
IPC	2023-08-01	2044.28320000	2026-08-31 22:02:54.272143+00
IPC	2023-09-01	2304.92420000	2026-08-31 22:02:54.272143+00
IPC	2023-10-01	2496.27300000	2026-08-31 22:02:54.272143+00
IPC	2023-11-01	2816.06280000	2026-08-31 22:02:54.272143+00
IPC	2023-12-01	3533.19220000	2026-08-31 22:02:54.272143+00
IPC	2024-01-01	4261.53240000	2026-08-31 22:02:54.272143+00
IPC	2024-02-01	4825.78810000	2026-08-31 22:02:54.272143+00
IPC	2024-03-01	5357.09290000	2026-08-31 22:02:54.272143+00
IPC	2024-04-01	5830.22710000	2026-08-31 22:02:54.272143+00
IPC	2024-05-01	6073.70000000	2026-08-31 22:02:54.272143+00
IPC	2024-06-01	6351.71450000	2026-08-31 22:02:54.272143+00
IPC	2024-07-01	6607.74790000	2026-08-31 22:02:54.272143+00
IPC	2024-08-01	6883.44120000	2026-08-31 22:02:54.272143+00
IPC	2024-09-01	7122.24210000	2026-08-31 22:02:54.272143+00
IPC	2024-10-01	7313.95420000	2026-08-31 22:02:54.272143+00
IPC	2024-11-01	7491.43140000	2026-08-31 22:02:54.272143+00
IPC	2024-12-01	7694.00750000	2026-08-31 22:02:54.272143+00
IPC	2025-01-01	7864.12570000	2026-08-31 22:02:54.272143+00
IPC	2025-02-01	8052.99270000	2026-08-31 22:02:54.272143+00
IPC	2025-03-01	8353.31580000	2026-08-31 22:02:54.272143+00
IPC	2025-04-01	8585.60780000	2026-08-31 22:02:54.272143+00
IPC	2021-01-01	401.50710000	2026-08-31 22:02:54.272143+00
IPC	2021-02-01	415.85950000	2026-08-31 22:02:54.272143+00
IPC	2021-03-01	435.86570000	2026-08-31 22:02:54.272143+00
IPC	2021-04-01	453.65030000	2026-08-31 22:02:54.272143+00
IPC	2021-05-01	468.72500000	2026-08-31 22:02:54.272143+00
IPC	2021-06-01	483.60490000	2026-08-31 22:02:54.272143+00
IPC	2021-07-01	498.09870000	2026-08-31 22:02:54.272143+00
IPC	2021-08-01	510.39420000	2026-08-31 22:02:54.272143+00
IPC	2021-09-01	528.49680000	2026-08-31 22:02:54.272143+00
IPC	2021-10-01	547.08020000	2026-08-31 22:02:54.272143+00
IPC	2021-11-01	560.91840000	2026-08-31 22:02:54.272143+00
IPC	2021-12-01	582.45750000	2026-08-31 22:02:54.272143+00
IPC	2022-01-01	605.03170000	2026-08-31 22:02:54.272143+00
IPC	2022-02-01	633.43410000	2026-08-31 22:02:54.272143+00
IPC	2022-03-01	676.05660000	2026-08-31 22:02:54.272143+00
IPC	2022-04-01	716.93990000	2026-08-31 22:02:54.272143+00
IPC	2022-05-01	753.14700000	2026-08-31 22:02:54.272143+00
IPC	2022-06-01	793.02780000	2026-08-31 22:02:54.272143+00
IPC	2022-07-01	851.76100000	2026-08-31 22:02:54.272143+00
IPC	2022-08-01	911.13160000	2026-08-31 22:02:54.272143+00
IPC	2022-09-01	967.30760000	2026-08-31 22:02:54.272143+00
IPC	2022-10-01	1028.70600000	2026-08-31 22:02:54.272143+00
IPC	2022-11-01	1079.27870000	2026-08-31 22:02:54.272143+00
IPC	2022-12-01	1134.58750000	2026-08-31 22:02:54.272143+00
IPC	2023-01-01	1202.97900000	2026-08-31 22:02:54.272143+00
IPC	2023-02-01	1282.70910000	2026-08-31 22:02:54.272143+00
IPC	2023-03-01	1381.16010000	2026-08-31 22:02:54.272143+00
IPC	2023-04-01	1497.21470000	2026-08-31 22:02:54.272143+00
IPC	2023-05-01	1613.58950000	2026-08-31 22:02:54.272143+00
IPC	2023-06-01	1709.61150000	2026-08-31 22:02:54.272143+00
IPC	2025-05-01	8714.48710000	2026-08-31 22:02:54.272143+00
IPC	2025-06-01	8855.56810000	2026-08-31 22:02:54.272143+00
IPC	2025-07-01	9023.97300000	2026-08-31 22:02:54.272143+00
IPC	2025-08-01	9193.24410000	2026-08-31 22:02:54.272143+00
IPC	2025-09-01	9384.09220000	2026-08-31 22:02:54.272143+00
IPC	2025-10-01	9603.86230000	2026-08-31 22:02:54.272143+00
IPC	2025-11-01	9841.35810000	2026-08-31 22:02:54.272143+00
IPC	2025-12-01	10121.37150000	2026-08-31 22:02:54.272143+00
IPC	2026-01-01	10413.03090000	2026-08-31 22:02:54.272143+00
\.


--
-- Data for Name: inquilinos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inquilinos (id, nombre, documento, telefono, email, notas, deleted_at, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: liquidacion_detalle; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.liquidacion_detalle (id, liquidacion_id, contrato_id, tipo, cobro_id, gasto_id, descripcion, monto_bruto, honorarios_porcentaje, honorarios_monto, neto, orden) FROM stdin;
\.


--
-- Data for Name: liquidaciones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.liquidaciones (id, numero, propietario_id, periodo, moneda, total_cobrado, total_honorarios, total_gastos, total_ajustes, neto_a_pagar, estado, metodo_pago, fecha_pago, comprobante_url, conformidad, recibido_por, notas, emitida_at, emitida_por, anulado_at, anulado_motivo, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: perfiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.perfiles (id, nombre, email, rol, created_at) FROM stdin;
9a231ace-4d19-4956-a69f-f20558bfc11e	Alex Solórzano	alex.solorzano62@gmail.com	admin	2026-08-29 03:34:02.000511+00
\.


--
-- Data for Name: propiedades; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.propiedades (id, propietario_id, titulares_adicionales, direccion, piso_depto, localidad, provincia, tipo, ambientes, superficie_m2, partida_inmobiliaria, cuenta_luz, cuenta_gas, cuenta_agua, expensas_unidad, estado, notas, deleted_at, created_at, created_by, edificio) FROM stdin;
7aced239-1585-443a-833c-b0b5d0cd64ce	7e4353eb-becb-4102-b644-510d9e973ece	\N	asda	4	4	Buenos Aires	departamento	0	4.00	e	e	e	e	e	disponible	\N	\N	2026-09-10 21:42:58.301237+00	9a231ace-4d19-4956-a69f-f20558bfc11e	asd
\.


--
-- Data for Name: propietarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.propietarios (id, nombre, documento, telefono, email, forma_cobro, cbu, alias_cbu, titular_cuenta, notas, deleted_at, created_at, created_by) FROM stdin;
7e4353eb-becb-4102-b644-510d9e973ece	Lamelas Pablo Agustin	30442885	\N	\N	transferencia	\N	\N	\N	\N	\N	2026-09-04 19:28:28.312311+00	9a231ace-4d19-4956-a69f-f20558bfc11e
\.


--
-- Data for Name: tareas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tareas (id, titulo, detalle, estado, prioridad, vence_el, propiedad_id, contrato_id, inquilino_id, completada_at, completada_por, deleted_at, created_at, created_by) FROM stdin;
76282c13-dc3c-4945-9877-f02f003092ef	Arreglar cañeria ayacucho  91	\N	hecha	alta	2026-09-05	\N	\N	\N	2026-09-04 14:44:30.690677+00	9a231ace-4d19-4956-a69f-f20558bfc11e	\N	2026-09-04 14:44:22.636852+00	9a231ace-4d19-4956-a69f-f20558bfc11e
687cea17-02f1-47b4-ab3a-58fe1f675147	Arreglar cañeria ayacucho  91	\N	hecha	normal	\N	\N	\N	\N	2026-09-08 12:51:51.069229+00	9a231ace-4d19-4956-a69f-f20558bfc11e	\N	2026-09-08 12:51:45.022768+00	9a231ace-4d19-4956-a69f-f20558bfc11e
0ac88c06-5fb3-4996-a471-37c1b5fee783	Arreglar cañeria ayacucho  91	ajsjda	hecha	alta	2026-09-17	\N	\N	\N	2026-09-10 21:46:46.691629+00	9a231ace-4d19-4956-a69f-f20558bfc11e	\N	2026-09-10 21:41:46.390026+00	9a231ace-4d19-4956-a69f-f20558bfc11e
dcbfc06c-af24-4804-9e12-4663f3dc6f58	sefwef	sefwfwef	hecha	normal	2026-09-04	\N	\N	\N	2026-09-11 19:41:43.242655+00	9a231ace-4d19-4956-a69f-f20558bfc11e	\N	2026-09-11 19:41:36.3877+00	9a231ace-4d19-4956-a69f-f20558bfc11e
\.


--
-- Name: liquidacion_numero_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.liquidacion_numero_seq', 1, false);


--
-- Name: recibo_numero_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recibo_numero_seq', 1, false);


--
-- Name: ajustes ajustes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ajustes
    ADD CONSTRAINT ajustes_pkey PRIMARY KEY (id);


--
-- Name: avisos_enviados avisos_enviados_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.avisos_enviados
    ADD CONSTRAINT avisos_enviados_pkey PRIMARY KEY (id);


--
-- Name: cobro_conceptos cobro_conceptos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cobro_conceptos
    ADD CONSTRAINT cobro_conceptos_pkey PRIMARY KEY (id);


--
-- Name: cobros cobros_numero_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cobros
    ADD CONSTRAINT cobros_numero_key UNIQUE (numero);


--
-- Name: cobros cobros_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cobros
    ADD CONSTRAINT cobros_pkey PRIMARY KEY (id);


--
-- Name: conceptos conceptos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conceptos
    ADD CONSTRAINT conceptos_pkey PRIMARY KEY (id);


--
-- Name: contrato_cargos contrato_cargos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contrato_cargos
    ADD CONSTRAINT contrato_cargos_pkey PRIMARY KEY (id);


--
-- Name: contratos contratos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contratos
    ADD CONSTRAINT contratos_pkey PRIMARY KEY (id);


--
-- Name: feriados feriados_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feriados
    ADD CONSTRAINT feriados_pkey PRIMARY KEY (fecha);


--
-- Name: gastos gastos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_pkey PRIMARY KEY (id);


--
-- Name: indices_valores indices_valores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indices_valores
    ADD CONSTRAINT indices_valores_pkey PRIMARY KEY (indice, fecha);


--
-- Name: inquilinos inquilinos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inquilinos
    ADD CONSTRAINT inquilinos_pkey PRIMARY KEY (id);


--
-- Name: liquidacion_detalle liquidacion_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidacion_detalle
    ADD CONSTRAINT liquidacion_detalle_pkey PRIMARY KEY (id);


--
-- Name: liquidaciones liquidaciones_numero_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidaciones
    ADD CONSTRAINT liquidaciones_numero_key UNIQUE (numero);


--
-- Name: liquidaciones liquidaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidaciones
    ADD CONSTRAINT liquidaciones_pkey PRIMARY KEY (id);


--
-- Name: perfiles perfiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.perfiles
    ADD CONSTRAINT perfiles_pkey PRIMARY KEY (id);


--
-- Name: propiedades propiedades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.propiedades
    ADD CONSTRAINT propiedades_pkey PRIMARY KEY (id);


--
-- Name: propietarios propietarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.propietarios
    ADD CONSTRAINT propietarios_pkey PRIMARY KEY (id);


--
-- Name: tareas tareas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tareas
    ADD CONSTRAINT tareas_pkey PRIMARY KEY (id);


--
-- Name: ajustes_contrato_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ajustes_contrato_idx ON public.ajustes USING btree (contrato_id, fecha_aplicacion DESC);


--
-- Name: avisos_contrato_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX avisos_contrato_idx ON public.avisos_enviados USING btree (contrato_id, tipo, periodo DESC);


--
-- Name: avisos_liquidacion_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX avisos_liquidacion_idx ON public.avisos_enviados USING btree (liquidacion_id);


--
-- Name: cobro_conceptos_cobro_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cobro_conceptos_cobro_idx ON public.cobro_conceptos USING btree (cobro_id, orden);


--
-- Name: cobros_contrato_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cobros_contrato_idx ON public.cobros USING btree (contrato_id, periodo DESC);


--
-- Name: cobros_contrato_periodo_unico; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cobros_contrato_periodo_unico ON public.cobros USING btree (contrato_id, periodo) WHERE (anulado_at IS NULL);


--
-- Name: cobros_periodo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cobros_periodo_idx ON public.cobros USING btree (periodo DESC) WHERE (anulado_at IS NULL);


--
-- Name: conceptos_nombre_unico; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX conceptos_nombre_unico ON public.conceptos USING btree (lower(TRIM(BOTH FROM nombre))) WHERE (deleted_at IS NULL);


--
-- Name: contrato_cargos_concepto_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contrato_cargos_concepto_idx ON public.contrato_cargos USING btree (concepto_id) WHERE (deleted_at IS NULL);


--
-- Name: contrato_cargos_contrato_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contrato_cargos_contrato_idx ON public.contrato_cargos USING btree (contrato_id) WHERE ((deleted_at IS NULL) AND activo);


--
-- Name: contratos_activos_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contratos_activos_idx ON public.contratos USING btree (fecha_proximo_ajuste) WHERE ((estado = 'activo'::text) AND (deleted_at IS NULL));


--
-- Name: contratos_inquilino_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contratos_inquilino_idx ON public.contratos USING btree (inquilino_id);


--
-- Name: contratos_propiedad_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contratos_propiedad_idx ON public.contratos USING btree (propiedad_id);


--
-- Name: gastos_pendientes_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gastos_pendientes_idx ON public.gastos USING btree (a_cargo_de, fecha) WHERE ((cobro_id IS NULL) AND (liquidacion_id IS NULL) AND (deleted_at IS NULL));


--
-- Name: gastos_propiedad_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gastos_propiedad_idx ON public.gastos USING btree (propiedad_id, fecha DESC);


--
-- Name: indices_valores_fecha_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX indices_valores_fecha_idx ON public.indices_valores USING btree (indice, fecha DESC);


--
-- Name: inquilinos_activos_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inquilinos_activos_idx ON public.inquilinos USING btree (nombre) WHERE (deleted_at IS NULL);


--
-- Name: liquidacion_detalle_cobro_unico; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX liquidacion_detalle_cobro_unico ON public.liquidacion_detalle USING btree (cobro_id) WHERE (cobro_id IS NOT NULL);


--
-- Name: liquidacion_detalle_liq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX liquidacion_detalle_liq_idx ON public.liquidacion_detalle USING btree (liquidacion_id, orden);


--
-- Name: liquidaciones_propietario_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX liquidaciones_propietario_idx ON public.liquidaciones USING btree (propietario_id, periodo DESC);


--
-- Name: liquidaciones_propietario_periodo_unico; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX liquidaciones_propietario_periodo_unico ON public.liquidaciones USING btree (propietario_id, periodo, moneda) WHERE (anulado_at IS NULL);


--
-- Name: propiedades_edificio_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX propiedades_edificio_idx ON public.propiedades USING btree (edificio) WHERE ((deleted_at IS NULL) AND (edificio IS NOT NULL));


--
-- Name: propiedades_propietario_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX propiedades_propietario_idx ON public.propiedades USING btree (propietario_id) WHERE (deleted_at IS NULL);


--
-- Name: propietarios_activos_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX propietarios_activos_idx ON public.propietarios USING btree (nombre) WHERE (deleted_at IS NULL);


--
-- Name: tareas_contrato_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tareas_contrato_idx ON public.tareas USING btree (contrato_id) WHERE (deleted_at IS NULL);


--
-- Name: tareas_pendientes_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tareas_pendientes_idx ON public.tareas USING btree (vence_el, created_at) WHERE ((deleted_at IS NULL) AND (estado = 'pendiente'::text));


--
-- Name: tareas_propiedad_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tareas_propiedad_idx ON public.tareas USING btree (propiedad_id) WHERE (deleted_at IS NULL);


--
-- Name: cobro_conceptos cobro_conceptos_sin_borrado; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cobro_conceptos_sin_borrado BEFORE DELETE ON public.cobro_conceptos FOR EACH ROW EXECUTE FUNCTION public.prohibir_borrado();


--
-- Name: cobros cobros_inmutables_trg; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cobros_inmutables_trg BEFORE UPDATE ON public.cobros FOR EACH ROW EXECUTE FUNCTION public.cobros_inmutables();


--
-- Name: cobros cobros_sin_borrado; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cobros_sin_borrado BEFORE DELETE ON public.cobros FOR EACH ROW EXECUTE FUNCTION public.prohibir_borrado();


--
-- Name: liquidacion_detalle detalle_liquidacion_emitida_trg; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER detalle_liquidacion_emitida_trg BEFORE INSERT OR DELETE OR UPDATE ON public.liquidacion_detalle FOR EACH ROW EXECUTE FUNCTION public.detalle_liquidacion_emitida();


--
-- Name: liquidaciones liquidaciones_inmutables_trg; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER liquidaciones_inmutables_trg BEFORE UPDATE ON public.liquidaciones FOR EACH ROW EXECUTE FUNCTION public.liquidaciones_inmutables();


--
-- Name: liquidaciones liquidaciones_sin_borrado; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER liquidaciones_sin_borrado BEFORE DELETE ON public.liquidaciones FOR EACH ROW EXECUTE FUNCTION public.prohibir_borrado();


--
-- Name: tareas tareas_sellar_completada; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tareas_sellar_completada BEFORE UPDATE ON public.tareas FOR EACH ROW EXECUTE FUNCTION public.tareas_sellar_completada();


--
-- Name: ajustes ajustes_contrato_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ajustes
    ADD CONSTRAINT ajustes_contrato_id_fkey FOREIGN KEY (contrato_id) REFERENCES public.contratos(id);


--
-- Name: ajustes ajustes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ajustes
    ADD CONSTRAINT ajustes_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: avisos_enviados avisos_enviados_contrato_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.avisos_enviados
    ADD CONSTRAINT avisos_enviados_contrato_id_fkey FOREIGN KEY (contrato_id) REFERENCES public.contratos(id);


--
-- Name: avisos_enviados avisos_enviados_enviado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.avisos_enviados
    ADD CONSTRAINT avisos_enviados_enviado_por_fkey FOREIGN KEY (enviado_por) REFERENCES auth.users(id);


--
-- Name: avisos_enviados avisos_enviados_liquidacion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.avisos_enviados
    ADD CONSTRAINT avisos_enviados_liquidacion_id_fkey FOREIGN KEY (liquidacion_id) REFERENCES public.liquidaciones(id);


--
-- Name: cobro_conceptos cobro_conceptos_cobro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cobro_conceptos
    ADD CONSTRAINT cobro_conceptos_cobro_id_fkey FOREIGN KEY (cobro_id) REFERENCES public.cobros(id) ON DELETE CASCADE;


--
-- Name: cobros cobros_anulado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cobros
    ADD CONSTRAINT cobros_anulado_por_fkey FOREIGN KEY (anulado_por) REFERENCES auth.users(id);


--
-- Name: cobros cobros_contrato_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cobros
    ADD CONSTRAINT cobros_contrato_id_fkey FOREIGN KEY (contrato_id) REFERENCES public.contratos(id);


--
-- Name: cobros cobros_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cobros
    ADD CONSTRAINT cobros_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: conceptos conceptos_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conceptos
    ADD CONSTRAINT conceptos_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: contrato_cargos contrato_cargos_concepto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contrato_cargos
    ADD CONSTRAINT contrato_cargos_concepto_id_fkey FOREIGN KEY (concepto_id) REFERENCES public.conceptos(id);


--
-- Name: contrato_cargos contrato_cargos_contrato_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contrato_cargos
    ADD CONSTRAINT contrato_cargos_contrato_id_fkey FOREIGN KEY (contrato_id) REFERENCES public.contratos(id);


--
-- Name: contrato_cargos contrato_cargos_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contrato_cargos
    ADD CONSTRAINT contrato_cargos_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: contratos contratos_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contratos
    ADD CONSTRAINT contratos_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: contratos contratos_inquilino_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contratos
    ADD CONSTRAINT contratos_inquilino_id_fkey FOREIGN KEY (inquilino_id) REFERENCES public.inquilinos(id);


--
-- Name: contratos contratos_propiedad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contratos
    ADD CONSTRAINT contratos_propiedad_id_fkey FOREIGN KEY (propiedad_id) REFERENCES public.propiedades(id);


--
-- Name: feriados feriados_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feriados
    ADD CONSTRAINT feriados_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: gastos gastos_cobro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_cobro_id_fkey FOREIGN KEY (cobro_id) REFERENCES public.cobros(id);


--
-- Name: gastos gastos_contrato_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_contrato_id_fkey FOREIGN KEY (contrato_id) REFERENCES public.contratos(id);


--
-- Name: gastos gastos_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: gastos gastos_liquidacion_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_liquidacion_fk FOREIGN KEY (liquidacion_id) REFERENCES public.liquidaciones(id);


--
-- Name: gastos gastos_propiedad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_propiedad_id_fkey FOREIGN KEY (propiedad_id) REFERENCES public.propiedades(id);


--
-- Name: inquilinos inquilinos_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inquilinos
    ADD CONSTRAINT inquilinos_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: liquidacion_detalle liquidacion_detalle_cobro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidacion_detalle
    ADD CONSTRAINT liquidacion_detalle_cobro_id_fkey FOREIGN KEY (cobro_id) REFERENCES public.cobros(id);


--
-- Name: liquidacion_detalle liquidacion_detalle_contrato_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidacion_detalle
    ADD CONSTRAINT liquidacion_detalle_contrato_id_fkey FOREIGN KEY (contrato_id) REFERENCES public.contratos(id);


--
-- Name: liquidacion_detalle liquidacion_detalle_gasto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidacion_detalle
    ADD CONSTRAINT liquidacion_detalle_gasto_id_fkey FOREIGN KEY (gasto_id) REFERENCES public.gastos(id);


--
-- Name: liquidacion_detalle liquidacion_detalle_liquidacion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidacion_detalle
    ADD CONSTRAINT liquidacion_detalle_liquidacion_id_fkey FOREIGN KEY (liquidacion_id) REFERENCES public.liquidaciones(id) ON DELETE CASCADE;


--
-- Name: liquidaciones liquidaciones_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidaciones
    ADD CONSTRAINT liquidaciones_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: liquidaciones liquidaciones_emitida_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidaciones
    ADD CONSTRAINT liquidaciones_emitida_por_fkey FOREIGN KEY (emitida_por) REFERENCES auth.users(id);


--
-- Name: liquidaciones liquidaciones_propietario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.liquidaciones
    ADD CONSTRAINT liquidaciones_propietario_id_fkey FOREIGN KEY (propietario_id) REFERENCES public.propietarios(id);


--
-- Name: perfiles perfiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.perfiles
    ADD CONSTRAINT perfiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: propiedades propiedades_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.propiedades
    ADD CONSTRAINT propiedades_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: propiedades propiedades_propietario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.propiedades
    ADD CONSTRAINT propiedades_propietario_id_fkey FOREIGN KEY (propietario_id) REFERENCES public.propietarios(id);


--
-- Name: propietarios propietarios_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.propietarios
    ADD CONSTRAINT propietarios_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: tareas tareas_completada_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tareas
    ADD CONSTRAINT tareas_completada_por_fkey FOREIGN KEY (completada_por) REFERENCES auth.users(id);


--
-- Name: tareas tareas_contrato_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tareas
    ADD CONSTRAINT tareas_contrato_id_fkey FOREIGN KEY (contrato_id) REFERENCES public.contratos(id);


--
-- Name: tareas tareas_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tareas
    ADD CONSTRAINT tareas_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: tareas tareas_inquilino_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tareas
    ADD CONSTRAINT tareas_inquilino_id_fkey FOREIGN KEY (inquilino_id) REFERENCES public.inquilinos(id);


--
-- Name: tareas tareas_propiedad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tareas
    ADD CONSTRAINT tareas_propiedad_id_fkey FOREIGN KEY (propiedad_id) REFERENCES public.propiedades(id);


--
-- Name: ajustes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ajustes ENABLE ROW LEVEL SECURITY;

--
-- Name: ajustes ajustes_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ajustes_insert ON public.ajustes FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: ajustes ajustes_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ajustes_select ON public.ajustes FOR SELECT USING (public.es_miembro());


--
-- Name: ajustes ajustes_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ajustes_update ON public.ajustes FOR UPDATE USING (public.es_miembro());


--
-- Name: avisos_enviados; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.avisos_enviados ENABLE ROW LEVEL SECURITY;

--
-- Name: avisos_enviados avisos_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY avisos_insert ON public.avisos_enviados FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: avisos_enviados avisos_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY avisos_select ON public.avisos_enviados FOR SELECT USING (public.es_miembro());


--
-- Name: cobro_conceptos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cobro_conceptos ENABLE ROW LEVEL SECURITY;

--
-- Name: cobro_conceptos cobro_conceptos_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cobro_conceptos_insert ON public.cobro_conceptos FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: cobro_conceptos cobro_conceptos_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cobro_conceptos_select ON public.cobro_conceptos FOR SELECT USING (public.es_miembro());


--
-- Name: cobros; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cobros ENABLE ROW LEVEL SECURITY;

--
-- Name: cobros cobros_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cobros_insert ON public.cobros FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: cobros cobros_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cobros_select ON public.cobros FOR SELECT USING (public.es_miembro());


--
-- Name: cobros cobros_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cobros_update ON public.cobros FOR UPDATE USING (public.es_admin());


--
-- Name: conceptos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.conceptos ENABLE ROW LEVEL SECURITY;

--
-- Name: conceptos conceptos_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY conceptos_insert ON public.conceptos FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: conceptos conceptos_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY conceptos_select ON public.conceptos FOR SELECT USING (public.es_miembro());


--
-- Name: conceptos conceptos_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY conceptos_update ON public.conceptos FOR UPDATE USING (public.es_miembro());


--
-- Name: contrato_cargos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.contrato_cargos ENABLE ROW LEVEL SECURITY;

--
-- Name: contrato_cargos contrato_cargos_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contrato_cargos_insert ON public.contrato_cargos FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: contrato_cargos contrato_cargos_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contrato_cargos_select ON public.contrato_cargos FOR SELECT USING (public.es_miembro());


--
-- Name: contrato_cargos contrato_cargos_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contrato_cargos_update ON public.contrato_cargos FOR UPDATE USING (public.es_miembro());


--
-- Name: contratos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.contratos ENABLE ROW LEVEL SECURITY;

--
-- Name: contratos contratos_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contratos_insert ON public.contratos FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: contratos contratos_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contratos_select ON public.contratos FOR SELECT USING (public.es_miembro());


--
-- Name: contratos contratos_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contratos_update ON public.contratos FOR UPDATE USING (public.es_miembro());


--
-- Name: feriados; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.feriados ENABLE ROW LEVEL SECURITY;

--
-- Name: feriados feriados_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY feriados_delete ON public.feriados FOR DELETE USING (public.es_miembro());


--
-- Name: feriados feriados_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY feriados_insert ON public.feriados FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: feriados feriados_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY feriados_select ON public.feriados FOR SELECT USING (public.es_miembro());


--
-- Name: gastos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.gastos ENABLE ROW LEVEL SECURITY;

--
-- Name: gastos gastos_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY gastos_insert ON public.gastos FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: gastos gastos_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY gastos_select ON public.gastos FOR SELECT USING (public.es_miembro());


--
-- Name: gastos gastos_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY gastos_update ON public.gastos FOR UPDATE USING (public.es_miembro());


--
-- Name: indices_valores indices_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY indices_select ON public.indices_valores FOR SELECT USING (public.es_miembro());


--
-- Name: indices_valores; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.indices_valores ENABLE ROW LEVEL SECURITY;

--
-- Name: inquilinos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inquilinos ENABLE ROW LEVEL SECURITY;

--
-- Name: inquilinos inquilinos_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY inquilinos_insert ON public.inquilinos FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: inquilinos inquilinos_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY inquilinos_select ON public.inquilinos FOR SELECT USING (public.es_miembro());


--
-- Name: inquilinos inquilinos_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY inquilinos_update ON public.inquilinos FOR UPDATE USING (public.es_miembro());


--
-- Name: liquidacion_detalle; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.liquidacion_detalle ENABLE ROW LEVEL SECURITY;

--
-- Name: liquidacion_detalle liquidacion_detalle_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY liquidacion_detalle_delete ON public.liquidacion_detalle FOR DELETE USING (public.es_miembro());


--
-- Name: liquidacion_detalle liquidacion_detalle_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY liquidacion_detalle_insert ON public.liquidacion_detalle FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: liquidacion_detalle liquidacion_detalle_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY liquidacion_detalle_select ON public.liquidacion_detalle FOR SELECT USING (public.es_miembro());


--
-- Name: liquidaciones; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.liquidaciones ENABLE ROW LEVEL SECURITY;

--
-- Name: liquidaciones liquidaciones_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY liquidaciones_insert ON public.liquidaciones FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: liquidaciones liquidaciones_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY liquidaciones_select ON public.liquidaciones FOR SELECT USING (public.es_miembro());


--
-- Name: liquidaciones liquidaciones_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY liquidaciones_update ON public.liquidaciones FOR UPDATE USING (public.es_miembro());


--
-- Name: perfiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.perfiles ENABLE ROW LEVEL SECURITY;

--
-- Name: perfiles perfiles_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY perfiles_select ON public.perfiles FOR SELECT USING (((id = auth.uid()) OR public.es_admin()));


--
-- Name: perfiles perfiles_update_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY perfiles_update_admin ON public.perfiles FOR UPDATE USING (public.es_admin());


--
-- Name: propiedades; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.propiedades ENABLE ROW LEVEL SECURITY;

--
-- Name: propiedades propiedades_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY propiedades_insert ON public.propiedades FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: propiedades propiedades_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY propiedades_select ON public.propiedades FOR SELECT USING (public.es_miembro());


--
-- Name: propiedades propiedades_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY propiedades_update ON public.propiedades FOR UPDATE USING (public.es_miembro());


--
-- Name: propietarios; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.propietarios ENABLE ROW LEVEL SECURITY;

--
-- Name: propietarios propietarios_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY propietarios_insert ON public.propietarios FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: propietarios propietarios_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY propietarios_select ON public.propietarios FOR SELECT USING (public.es_miembro());


--
-- Name: propietarios propietarios_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY propietarios_update ON public.propietarios FOR UPDATE USING (public.es_miembro());


--
-- Name: tareas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tareas ENABLE ROW LEVEL SECURITY;

--
-- Name: tareas tareas_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tareas_insert ON public.tareas FOR INSERT WITH CHECK (public.es_miembro());


--
-- Name: tareas tareas_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tareas_select ON public.tareas FOR SELECT USING (public.es_miembro());


--
-- Name: tareas tareas_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tareas_update ON public.tareas FOR UPDATE USING (public.es_miembro());


--
-- PostgreSQL database dump complete
--

\unrestrict mADGp7m70J7OFEkVqBwCTd3AT8riEbp9fXmUilPxVECccWtdpcmGOIqxUOjA0LA

